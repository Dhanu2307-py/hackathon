import React from 'react'
import { ThemeProvider, CssBaseline } from '@mui/material'
import { useSelector } from 'react-redux'
import { lightTheme, darkTheme } from './theme/theme'
import AppRoutes from './routes/AppRoutes'
import { SnackbarProvider } from './components/SnackbarProvider'

function App() {
  const themeMode = useSelector((s) => s.ui.themeMode)
  const activeTheme = themeMode === 'dark' ? darkTheme : lightTheme

  return (
    <ThemeProvider theme={activeTheme}>
      <CssBaseline />
      <SnackbarProvider>
        <AppRoutes />
      </SnackbarProvider>
    </ThemeProvider>
  )
}

export default App
