import { createSlice } from '@reduxjs/toolkit'

const savedMode = localStorage.getItem('themeMode') || 'light'

const uiSlice = createSlice({
  name: 'ui',
  initialState: {
    sidebarOpen: true,
    themeMode: savedMode,
    snackbar: {
      open: false,
      message: '',
      severity: 'info',
    },
  },
  reducers: {
    toggleSidebar(state) {
      state.sidebarOpen = !state.sidebarOpen
    },
    setSidebarOpen(state, action) {
      state.sidebarOpen = action.payload
    },
    toggleThemeMode(state) {
      state.themeMode = state.themeMode === 'light' ? 'dark' : 'light'
      localStorage.setItem('themeMode', state.themeMode)
    },
    setThemeMode(state, action) {
      state.themeMode = action.payload
      localStorage.setItem('themeMode', action.payload)
    },
    showSnackbar(state, action) {
      state.snackbar = {
        open: true,
        message: action.payload.message,
        severity: action.payload.severity || 'info',
      }
    },
    hideSnackbar(state) {
      state.snackbar.open = false
    },
  },
})

export const { toggleSidebar, setSidebarOpen, toggleThemeMode, setThemeMode, showSnackbar, hideSnackbar } = uiSlice.actions
export default uiSlice.reducer
