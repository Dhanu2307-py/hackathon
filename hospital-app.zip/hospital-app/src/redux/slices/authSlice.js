import { createSlice } from '@reduxjs/toolkit'

const getInitialState = () => {
  try {
    const token = localStorage.getItem('token')
    const user = JSON.parse(localStorage.getItem('user') || 'null')
    const role = localStorage.getItem('role')
    return { token, user, role, isAuthenticated: !!token }
  } catch {
    return { token: null, user: null, role: null, isAuthenticated: false }
  }
}

const authSlice = createSlice({
  name: 'auth',
  initialState: getInitialState(),
  reducers: {
    loginSuccess(state, action) {
      const { token, user, role } = action.payload
      state.token = token
      state.user = user
      state.role = role
      state.isAuthenticated = true
      localStorage.setItem('token', token)
      localStorage.setItem('user', JSON.stringify(user))
      localStorage.setItem('role', role)
    },
    logout(state) {
      state.token = null
      state.user = null
      state.role = null
      state.isAuthenticated = false
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      localStorage.removeItem('role')
    },
    updateToken(state, action) {
      state.token = action.payload
      localStorage.setItem('token', action.payload)
    },
  },
})

export const { loginSuccess, logout, updateToken } = authSlice.actions
export default authSlice.reducer
