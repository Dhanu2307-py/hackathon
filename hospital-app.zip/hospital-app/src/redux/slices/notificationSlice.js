import { createSlice } from '@reduxjs/toolkit'

const notificationSlice = createSlice({
  name: 'notifications',
  initialState: {
    items: [],
    unreadCount: 0,
  },
  reducers: {
    setNotifications(state, action) {
      // Backend returns isRead (boolean); normalise to read for internal use
      state.items = action.payload.map(n => ({
        ...n,
        read: n.isRead ?? n.read ?? false,
      }))
      state.unreadCount = state.items.filter(n => !n.read).length
    },
    markAsRead(state, action) {
      const item = state.items.find(n => n.id === action.payload)
      if (item && !item.read) {
        item.read = true
        item.isRead = true
        state.unreadCount = Math.max(0, state.unreadCount - 1)
      }
    },
    markAllRead(state) {
      state.items.forEach(n => {
        n.read = true
        n.isRead = true
      })
      state.unreadCount = 0
    },
    addNotification(state, action) {
      const n = { ...action.payload, read: action.payload.isRead ?? action.payload.read ?? false }
      state.items.unshift(n)
      if (!n.read) state.unreadCount += 1
    },
  },
})

export const { setNotifications, markAsRead, markAllRead, addNotification } = notificationSlice.actions
export default notificationSlice.reducer
