import apiClient from './apiClient'

// Auth Service routes through API Gateway → /auth/**
const AUTH = '/auth'

const authService = {
  // POST /auth/login
  // Request:  { email, password }
  // Response: { success, message, data: { token, role, user: { id, name, email, role, status } } }
  async login(credentials) {
    const res = await apiClient.post(`${AUTH}/login`, credentials)
    return res.data.data  // { token, role, user }
  },

  // POST /auth/register/patient
  // Request:  { name, email, password, phoneNumber }
  // Response: { success, message, data: { token, role, user } }
  async registerPatient(data) {
    const res = await apiClient.post(`${AUTH}/register/patient`, data)
    return res.data.data
  },

  // POST /auth/register/doctor
  // Request:  { doctorName, email, phone, password, qualification, specialization,
  //             experience, licenseNumber, consultationFee, departmentId }
  // Response: { success, message, data: { token: null, role, user } }
  async registerDoctor(data) {
    const res = await apiClient.post(`${AUTH}/register/doctor`, data)
    return res.data.data
  },

  // GET /auth/profile  (requires JWT)
  // Response: { success, data: { id, name, email, role, status } }
  async getProfile() {
    const res = await apiClient.get(`${AUTH}/profile`)
    return res.data.data
  },
}

export default authService
