import axios from 'axios'
import store from '../redux/store'
import { logout } from '../redux/slices/authSlice'
import { showSnackbar } from '../redux/slices/uiSlice'

// All requests go through API Gateway at port 8080
const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_GATEWAY || 'http://localhost:8080',
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
})

// Attach JWT Bearer token automatically to every request
apiClient.interceptors.request.use(
  (config) => {
    const token = store.getState().auth.token
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

// Handle responses globally
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      store.dispatch(logout())
      store.dispatch(showSnackbar({ message: 'Session expired. Please log in again.', severity: 'warning' }))
      window.location.href = '/login'
    } else if (error.response?.status === 403) {
      store.dispatch(showSnackbar({ message: 'Access denied. You do not have permission.', severity: 'error' }))
    } else if (error.response?.status === 404) {
      store.dispatch(showSnackbar({ message: 'Resource not found.', severity: 'error' }))
    } else if (error.response?.status >= 500) {
      store.dispatch(showSnackbar({ message: 'Server error. Please try again later.', severity: 'error' }))
    } else if (!error.response) {
      store.dispatch(showSnackbar({ message: 'Network error. Please check your connection.', severity: 'error' }))
    }
    return Promise.reject(error)
  }
)

export default apiClient
