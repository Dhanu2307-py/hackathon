import apiClient from './apiClient'

// Patient Service routes through API Gateway → /api/patients/**
const BASE = '/api/patients'

const patientService = {
  // POST /api/patients?authUserId={authUserId}
  // Request: PatientRequest { firstName, lastName, gender, dateOfBirth, bloodGroup,
  //                           phoneNumber, email, address, city, state, pincode }
  // Response: PatientResponse { patientId, patientNumber, firstName, lastName,
  //           gender, dateOfBirth, bloodGroup, phoneNumber, email, address,
  //           city, state, pincode, status, createdAt }
  async create(data, authUserId) {
    const res = await apiClient.post(BASE, data, { params: { authUserId } })
    return res.data
  },

  // GET /api/patients
  // Response: List<PatientResponse>
  async getAll() {
    const res = await apiClient.get(BASE)
    return res.data
  },

  // GET /api/patients/{patientId}
  async getById(patientId) {
    const res = await apiClient.get(`${BASE}/${patientId}`)
    return res.data
  },

  // GET /api/patients/search?keyword={keyword}
  async search(keyword) {
    const res = await apiClient.get(`${BASE}/search`, { params: { keyword } })
    return res.data
  },

  // PUT /api/patients/{patientId}
  // Request: PatientUpdateRequest (all fields optional)
  async update(patientId, data) {
    const res = await apiClient.put(`${BASE}/${patientId}`, data)
    return res.data
  },

  // DELETE /api/patients/{patientId}  (soft delete)
  async delete(patientId) {
    const res = await apiClient.delete(`${BASE}/${patientId}`)
    return res.data
  },

  // GET /api/patients/{patientId}/appointments
  async getAppointments(patientId) {
    const res = await apiClient.get(`${BASE}/${patientId}/appointments`)
    return res.data
  },

  // GET /api/patients/{patientId}/payments
  async getPayments(patientId) {
    const res = await apiClient.get(`${BASE}/${patientId}/payments`)
    return res.data
  },

  // GET /api/patients/{patientId}/reports
  async getReports(patientId) {
    const res = await apiClient.get(`${BASE}/${patientId}/reports`)
    return res.data
  },

  // ─── Emergency Contacts ────────────────────────────────────────────────────

  // POST /api/patients/{patientId}/emergency-contacts
  // Request: { contactName, relationship, phoneNumber, address }
  async addEmergencyContact(patientId, data) {
    const res = await apiClient.post(`${BASE}/${patientId}/emergency-contacts`, data)
    return res.data
  },

  // GET /api/patients/{patientId}/emergency-contacts
  async getEmergencyContacts(patientId) {
    const res = await apiClient.get(`${BASE}/${patientId}/emergency-contacts`)
    return res.data
  },

  // PUT /api/emergency-contacts/{contactId}
  async updateEmergencyContact(contactId, data) {
    const res = await apiClient.put(`/api/emergency-contacts/${contactId}`, data)
    return res.data
  },

  // DELETE /api/emergency-contacts/{contactId}
  async deleteEmergencyContact(contactId) {
    const res = await apiClient.delete(`/api/emergency-contacts/${contactId}`)
    return res.data
  },
}

export default patientService
