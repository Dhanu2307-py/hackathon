import apiClient from './apiClient'

// Appointment Service → /appointments/**
const BASE = '/appointments'

const appointmentService = {
  // POST /appointments
  // Request: BookAppointmentRequest {
  //   patientProfileId, doctorId, departmentId,
  //   appointmentDate (YYYY-MM-DD), appointmentTime (HH:mm),
  //   reason
  // }
  // Response: AppointmentResponse {
  //   appointmentId, patientProfileId, doctorId, departmentId,
  //   appointmentDate, appointmentTime, status, paymentStatus,
  //   consultationFee, message
  // }
  async book(data) {
    const res = await apiClient.post(BASE, data)
    return res.data
  },

  // GET /appointments/{appointmentId}
  async getById(appointmentId) {
    const res = await apiClient.get(`${BASE}/${appointmentId}`)
    return res.data
  },

  // GET /appointments/patient/{profileId}
  async getByPatient(profileId) {
    const res = await apiClient.get(`${BASE}/patient/${profileId}`)
    return res.data
  },

  // GET /appointments/doctor/{doctorId}
  async getByDoctor(doctorId) {
    const res = await apiClient.get(`${BASE}/doctor/${doctorId}`)
    return res.data
  },

  // PUT /appointments/{appointmentId}/confirm
  // Request: ConfirmAppointmentRequest { confirmedBy, email }
  async confirm(appointmentId, data) {
    const res = await apiClient.put(`${BASE}/${appointmentId}/confirm`, data)
    return res.data
  },

  // PUT /appointments/{appointmentId}/cancel
  // Request: CancelAppointmentRequest { reason, cancelledBy, email }
  async cancel(appointmentId, data) {
    const res = await apiClient.put(`${BASE}/${appointmentId}/cancel`, data)
    return res.data
  },

  // PUT /appointments/{appointmentId}/reschedule
  // Request: RescheduleAppointmentRequest { newDate, newTime, remarks, requestedBy, email }
  async reschedule(appointmentId, data) {
    const res = await apiClient.put(`${BASE}/${appointmentId}/reschedule`, data)
    return res.data
  },

  // PUT /appointments/{appointmentId}/complete  (no request body)
  async complete(appointmentId) {
    const res = await apiClient.put(`${BASE}/${appointmentId}/complete`)
    return res.data
  },

  // GET /appointments/{appointmentId}/history
  // Response: List<AppointmentHistoryResponse> {
  //   id, appointmentId, oldStatus, newStatus, action, remarks, changedBy, changedAt
  // }
  async getHistory(appointmentId) {
    const res = await apiClient.get(`${BASE}/${appointmentId}/history`)
    return res.data
  },
}

export default appointmentService
