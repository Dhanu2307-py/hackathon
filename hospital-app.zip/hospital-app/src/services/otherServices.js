import apiClient from './apiClient'

// ─── Payment Service → /payments/** ──────────────────────────────────────────
export const paymentService = {
  // POST /payments
  // Request: { appointmentId, patientId, doctorId, amount }
  // Response: { paymentId, appointmentId, patientId, amount, status }
  async create(data) {
    const res = await apiClient.post('/payments', data)
    return res.data
  },

  // GET /payments/{id}
  async getById(id) {
    const res = await apiClient.get(`/payments/${id}`)
    return res.data
  },

  // POST /payments/refund/{id}
  async refund(id) {
    const res = await apiClient.post(`/payments/refund/${id}`)
    return res.data
  },
}

// ─── Report Service → /reports/**, /prescriptions/** ─────────────────────────
export const reportService = {
  // POST /reports
  // Request: { appointmentId, patientProfileId, doctorId, diagnosis, remarks, nextVisitDate }
  // Response: ReportResponse { reportId, appointmentId, patientProfileId, doctorId,
  //           diagnosis, remarks, nextVisitDate, status, version, createdAt }
  async create(data) {
    const res = await apiClient.post('/reports', data)
    return res.data
  },

  // GET /reports/{reportId}
  async getById(reportId) {
    const res = await apiClient.get(`/reports/${reportId}`)
    return res.data
  },

  // GET /reports/patient/{profileId}
  async getByPatient(profileId) {
    const res = await apiClient.get(`/reports/patient/${profileId}`)
    return res.data
  },

  // GET /reports/appointment/{appointmentId}
  async getByAppointment(appointmentId) {
    const res = await apiClient.get(`/reports/appointment/${appointmentId}`)
    return res.data
  },

  // GET /reports/doctor/{doctorId}
  async getByDoctor(doctorId) {
    const res = await apiClient.get(`/reports/doctor/${doctorId}`)
    return res.data
  },

  // PUT /reports/{reportId}
  // Request: { diagnosis, remarks, nextVisitDate }
  async update(reportId, data) {
    const res = await apiClient.put(`/reports/${reportId}`, data)
    return res.data
  },

  // DELETE /reports/{reportId}
  async delete(reportId) {
    const res = await apiClient.delete(`/reports/${reportId}`)
    return res.data
  },

  // GET /reports/{reportId}/pdf
  async downloadPdf(reportId) {
    const res = await apiClient.get(`/reports/${reportId}/pdf`, { responseType: 'blob' })
    return res.data
  },

  // POST /reports/{reportId}/attachments  (multipart)
  async uploadAttachment(reportId, file) {
    const formData = new FormData()
    formData.append('file', file)
    const res = await apiClient.post(`/reports/${reportId}/attachments`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    return res.data
  },

  // DELETE /reports/attachments/{attachmentId}
  async deleteAttachment(attachmentId) {
    const res = await apiClient.delete(`/reports/attachments/${attachmentId}`)
    return res.data
  },

  // POST /reports/{reportId}/prescriptions
  // Request: { medicineName, dosage, frequency, duration, instructions }
  async addPrescription(reportId, data) {
    const res = await apiClient.post(`/reports/${reportId}/prescriptions`, data)
    return res.data
  },

  // GET /reports/{reportId}/prescriptions
  async getPrescriptions(reportId) {
    const res = await apiClient.get(`/reports/${reportId}/prescriptions`)
    return res.data
  },

  // PUT /prescriptions/{prescriptionId}
  async updatePrescription(prescriptionId, data) {
    const res = await apiClient.put(`/prescriptions/${prescriptionId}`, data)
    return res.data
  },

  // DELETE /prescriptions/{prescriptionId}
  async deletePrescription(prescriptionId) {
    const res = await apiClient.delete(`/prescriptions/${prescriptionId}`)
    return res.data
  },
}

// ─── Notification Service → /notifications/** ─────────────────────────────────
export const notificationService = {
  // GET /notifications?userId={userId}
  // Response: List<NotificationDTO> { id, userId, userRole, title, message,
  //           type, referenceId, referenceType, isRead, createdAt }
  async getAll(userId) {
    const res = await apiClient.get('/notifications', { params: { userId } })
    return res.data
  },

  // GET /notifications/unread-count?userId={userId}
  async getUnreadCount(userId) {
    const res = await apiClient.get('/notifications/unread-count', { params: { userId } })
    return res.data
  },

  // PUT /notifications/{id}/read  (PUT not PATCH)
  async markRead(id) {
    const res = await apiClient.put(`/notifications/${id}/read`)
    return res.data
  },

  // PUT /notifications/read-all?userId={userId}
  async markAllRead(userId) {
    const res = await apiClient.put('/notifications/read-all', null, { params: { userId } })
    return res.data
  },
}
