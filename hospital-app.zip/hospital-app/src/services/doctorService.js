import apiClient from './apiClient'

// Doctor Service routes through API Gateway
const DOCTORS   = '/doctors'
const ADMIN     = '/admin/doctors'
const DEPT      = '/departments'
const AVAIL     = '/availability'
const LEAVES    = '/leaves'

const doctorService = {
  // ─── Doctors ───────────────────────────────────────────────────────────────

  // GET /doctors
  // Response: List<DoctorResponse> { doctorId, doctorName, email, phone,
  //   qualification, specialization, experience, licenseNumber,
  //   consultationFee, departmentName, approvalStatus, status }
  async getAll() {
    const res = await apiClient.get(DOCTORS)
    return res.data
  },

  // GET /doctors/{id}
  async getById(id) {
    const res = await apiClient.get(`${DOCTORS}/${id}`)
    return res.data
  },

  // GET /doctors/department/{departmentId}
  async getByDepartment(departmentId) {
    const res = await apiClient.get(`${DOCTORS}/department/${departmentId}`)
    return res.data
  },

  // PUT /doctors/{id}
  // Request: DoctorRequest
  async update(id, data) {
    const res = await apiClient.put(`${DOCTORS}/${id}`, data)
    return res.data
  },

  // DELETE /doctors/{id}
  async delete(id) {
    const res = await apiClient.delete(`${DOCTORS}/${id}`)
    return res.data
  },

  // ─── Admin Doctor Actions ──────────────────────────────────────────────────

  // GET /admin/doctors/pending
  async getPendingDoctors() {
    const res = await apiClient.get(`${ADMIN}/pending`)
    return res.data
  },

  // PUT /admin/doctors/{id}/approve
  async approve(id) {
    const res = await apiClient.put(`${ADMIN}/${id}/approve`)
    return res.data
  },

  // PUT /admin/doctors/{id}/reject
  async reject(id) {
    const res = await apiClient.put(`${ADMIN}/${id}/reject`)
    return res.data
  },

  // ─── Departments ──────────────────────────────────────────────────────────

  // GET /departments
  // Response: List<DepartmentResponse> { departmentId, departmentName, description, status }
  async getAllDepartments() {
    const res = await apiClient.get(DEPT)
    return res.data
  },

  // GET /departments/{id}
  async getDepartment(id) {
    const res = await apiClient.get(`${DEPT}/${id}`)
    return res.data
  },

  // POST /departments
  // Request: { departmentName, description }
  async createDepartment(data) {
    const res = await apiClient.post(DEPT, data)
    return res.data
  },

  // PUT /departments/{id}
  async updateDepartment(id, data) {
    const res = await apiClient.put(`${DEPT}/${id}`, data)
    return res.data
  },

  // ─── Availability ──────────────────────────────────────────────────────────

  // GET /availability/doctor/{doctorId}
  // Response: List<AvailabilityResponse> { availabilityId, doctorName,
  //   dayOfWeek, startTime, endTime, slotDuration, available }
  async getAvailability(doctorId) {
    const res = await apiClient.get(`${AVAIL}/doctor/${doctorId}`)
    return res.data
  },

  // POST /availability
  // Request: { doctorId, dayOfWeek, startTime, endTime, slotDuration }
  // dayOfWeek: MONDAY|TUESDAY|WEDNESDAY|THURSDAY|FRIDAY|SATURDAY|SUNDAY
  async addAvailability(data) {
    const res = await apiClient.post(AVAIL, data)
    return res.data
  },

  // PUT /availability/{availabilityId}
  async updateAvailability(availabilityId, data) {
    const res = await apiClient.put(`${AVAIL}/${availabilityId}`, data)
    return res.data
  },

  // DELETE /availability/{availabilityId}
  async deleteAvailability(availabilityId) {
    const res = await apiClient.delete(`${AVAIL}/${availabilityId}`)
    return res.data
  },

  // ─── Leaves ───────────────────────────────────────────────────────────────

  // POST /leaves
  // Request: { doctorId, leaveDate, reason }
  async applyLeave(data) {
    const res = await apiClient.post(LEAVES, data)
    return res.data
  },

  // GET /leaves/doctor/{doctorId}
  async getDoctorLeaves(doctorId) {
    const res = await apiClient.get(`${LEAVES}/doctor/${doctorId}`)
    return res.data
  },

  // PUT /leaves/{leaveId}/approve
  async approveLeave(leaveId) {
    const res = await apiClient.put(`${LEAVES}/${leaveId}/approve`)
    return res.data
  },

  // PUT /leaves/{leaveId}/reject
  async rejectLeave(leaveId) {
    const res = await apiClient.put(`${LEAVES}/${leaveId}/reject`)
    return res.data
  },
}

export default doctorService
