import React, { useState } from 'react'
import { Box, Card, CardContent, Typography, TextField, Button, Alert } from '@mui/material'
import { Email, MedicalServices } from '@mui/icons-material'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { Link as RouterLink } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { showSnackbar } from '../../redux/slices/uiSlice'
import authService from '../../services/authService'

const schema = yup.object({ email: yup.string().email('Invalid email').required('Email is required') })

function ForgotPassword() {
  const dispatch = useDispatch()
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: yupResolver(schema) })

  const onSubmit = async (data) => {
    setLoading(true)
    try {
      await authService.forgotPassword(data.email)
      setSent(true)
      dispatch(showSnackbar({ message: 'Reset link sent to your email!', severity: 'success' }))
    } catch {
      dispatch(showSnackbar({ message: 'Failed to send reset link.', severity: 'error' }))
    } finally {
      setLoading(false)
    }
  }

  return (
    <Box sx={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', bgcolor: 'background.default', p: 2 }}>
      <Card sx={{ width: '100%', maxWidth: 440 }}>
        <CardContent sx={{ p: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 3 }}>
            <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: 'primary.main', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <MedicalServices sx={{ color: 'white', fontSize: 20 }} />
            </Box>
            <Typography variant="h5" fontWeight={700}>Forgot Password</Typography>
          </Box>

          {sent ? (
            <Alert severity="success" sx={{ borderRadius: 2 }}>
              A password reset link has been sent to your email. Please check your inbox.
            </Alert>
          ) : (
            <>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Enter your email address and we'll send you a link to reset your password.
              </Typography>
              <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
                <TextField
                  label="Email Address"
                  type="email"
                  fullWidth
                  {...register('email')}
                  error={!!errors.email}
                  helperText={errors.email?.message}
                  InputProps={{ startAdornment: <Email sx={{ mr: 1, color: 'text.secondary' }} /> }}
                />
                <Button type="submit" variant="contained" fullWidth size="large" disabled={loading}>
                  {loading ? 'Sending…' : 'Send Reset Link'}
                </Button>
              </Box>
            </>
          )}

          <Box sx={{ mt: 2, textAlign: 'center' }}>
            <Button component={RouterLink} to="/login" color="primary" sx={{ textTransform: 'none' }}>
              ← Back to Login
            </Button>
          </Box>
        </CardContent>
      </Card>
    </Box>
  )
}

export default ForgotPassword
