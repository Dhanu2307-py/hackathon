import React, { useState } from 'react'
import { Box, Card, CardContent, Typography, TextField, Button, Alert, InputAdornment, IconButton } from '@mui/material'
import { Visibility, VisibilityOff, MedicalServices } from '@mui/icons-material'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useNavigate, Link as RouterLink } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { showSnackbar } from '../../redux/slices/uiSlice'
import authService from '../../services/authService'

const schema = yup.object({
  name:            yup.string().required('Full name is required'),
  email:           yup.string().email('Invalid email').required('Email is required'),
  phoneNumber:     yup.string().required('Phone is required'),
  password:        yup.string().min(6, 'Min 6 characters').required('Password is required'),
  confirmPassword: yup.string().oneOf([yup.ref('password')], 'Passwords must match').required('Confirm password'),
})

function RegisterPatient() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: yupResolver(schema) })

  const onSubmit = async ({ confirmPassword, ...data }) => {
    setLoading(true)
    setError('')
    try {
      // Auth Service registers the user account only.
      // Full patient profile (DOB, address etc.) is created separately in Patient Service.
      await authService.registerPatient(data)
      dispatch(showSnackbar({ message: 'Registration successful! Please log in.', severity: 'success' }))
      navigate('/login')
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Box sx={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', bgcolor: 'background.default', p: 2 }}>
      <Card sx={{ width: '100%', maxWidth: 480 }}>
        <CardContent sx={{ p: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 3 }}>
            <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: 'primary.main', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <MedicalServices sx={{ color: 'white', fontSize: 20 }} />
            </Box>
            <Typography variant="h5" fontWeight={700}>Patient Registration</Typography>
          </Box>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            Create your account to book appointments and manage your health records.
          </Typography>

          {error && <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>{error}</Alert>}

          <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
            <TextField label="Full Name" fullWidth {...register('name')} error={!!errors.name} helperText={errors.name?.message} />
            <TextField label="Email Address" type="email" fullWidth {...register('email')} error={!!errors.email} helperText={errors.email?.message} />
            <TextField label="Phone Number" fullWidth {...register('phoneNumber')} error={!!errors.phoneNumber} helperText={errors.phoneNumber?.message} />
            <TextField
              label="Password" type={showPass ? 'text' : 'password'} fullWidth
              {...register('password')} error={!!errors.password} helperText={errors.password?.message}
              InputProps={{ endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={() => setShowPass(p => !p)} edge="end" size="small">
                    {showPass ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              )}}
            />
            <TextField label="Confirm Password" type="password" fullWidth {...register('confirmPassword')} error={!!errors.confirmPassword} helperText={errors.confirmPassword?.message} />
            <Button type="submit" variant="contained" fullWidth size="large" disabled={loading} sx={{ mt: 1 }}>
              {loading ? 'Registering…' : 'Register'}
            </Button>
            <Button component={RouterLink} to="/login" variant="outlined" fullWidth>Back to Login</Button>
          </Box>
        </CardContent>
      </Card>
    </Box>
  )
}

export default RegisterPatient
