import React, { useState, useEffect } from 'react'
import {
  Box, Card, CardContent, Typography, TextField, Button, Alert,
  MenuItem, Paper, Grid
} from '@mui/material'
import { Info, MedicalServices } from '@mui/icons-material'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useNavigate, Link as RouterLink } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { showSnackbar } from '../../redux/slices/uiSlice'
import authService from '../../services/authService'
import doctorService from '../../services/doctorService'

const schema = yup.object({
  doctorName:      yup.string().required('Doctor name is required'),
  email:           yup.string().email('Invalid email').required('Email is required'),
  phone:           yup.string().required('Phone is required'),
  password:        yup.string().min(6, 'Min 6 characters').required('Password is required'),
  qualification:   yup.string().required('Qualification is required'),
  specialization:  yup.string().required('Specialization is required'),
  experience:      yup.number().typeError('Must be a number').min(0).required('Experience is required'),
  licenseNumber:   yup.string().required('License number is required'),
  consultationFee: yup.number().typeError('Must be a number').min(0).required('Consultation fee is required'),
  departmentId:    yup.number().typeError('Select a department').required('Department is required'),
})

function RegisterDoctor() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [departments, setDepartments] = useState([])

  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: yupResolver(schema) })

  // Load departments from Doctor Service
  useEffect(() => {
    doctorService.getAllDepartments()
      .then(setDepartments)
      .catch(() => setDepartments([]))
  }, [])

  const onSubmit = async (data) => {
    setLoading(true)
    setError('')
    try {
      // Sends to Auth Service POST /auth/register/doctor
      // Fields: doctorName, email, phone, password, qualification,
      //         specialization, experience, licenseNumber, consultationFee, departmentId
      await authService.registerDoctor(data)
      dispatch(showSnackbar({ message: 'Registration submitted. Awaiting admin approval.', severity: 'info' }))
      navigate('/login')
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Box sx={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', bgcolor: 'background.default', p: 2 }}>
      <Card sx={{ width: '100%', maxWidth: 600 }}>
        <CardContent sx={{ p: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 3 }}>
            <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: 'primary.main', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <MedicalServices sx={{ color: 'white', fontSize: 20 }} />
            </Box>
            <Typography variant="h5" fontWeight={700}>Doctor Registration</Typography>
          </Box>

          <Paper sx={{ p: 2, mb: 3, bgcolor: '#EFF6FF', border: '1px solid #BFDBFE', borderRadius: 2, display: 'flex', alignItems: 'flex-start', gap: 1.5 }}>
            <Info sx={{ color: '#2563EB', fontSize: 20, mt: 0.2 }} />
            <Typography variant="body2" sx={{ color: '#1D4ED8' }}>
              Your registration will remain <strong>pending</strong> until approved by the administrator.
            </Typography>
          </Paper>

          {error && <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>{error}</Alert>}

          <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate>
            <Grid container spacing={2.5}>
              <Grid item xs={12}>
                <TextField label="Full Name" fullWidth {...register('doctorName')} error={!!errors.doctorName} helperText={errors.doctorName?.message} />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField label="Email Address" type="email" fullWidth {...register('email')} error={!!errors.email} helperText={errors.email?.message} />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField label="Phone Number" fullWidth {...register('phone')} error={!!errors.phone} helperText={errors.phone?.message} />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField label="Qualification" fullWidth {...register('qualification')} error={!!errors.qualification} helperText={errors.qualification?.message} placeholder="e.g. MBBS, MD" />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField label="Specialization" fullWidth {...register('specialization')} error={!!errors.specialization} helperText={errors.specialization?.message} />
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField label="Experience (years)" type="number" fullWidth {...register('experience')} error={!!errors.experience} helperText={errors.experience?.message} inputProps={{ min: 0 }} />
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField label="License Number" fullWidth {...register('licenseNumber')} error={!!errors.licenseNumber} helperText={errors.licenseNumber?.message} />
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField label="Consultation Fee (₹)" type="number" fullWidth {...register('consultationFee')} error={!!errors.consultationFee} helperText={errors.consultationFee?.message} inputProps={{ min: 0 }} />
              </Grid>
              <Grid item xs={12}>
                <TextField select label="Department" fullWidth defaultValue="" {...register('departmentId')} error={!!errors.departmentId} helperText={errors.departmentId?.message}>
                  {departments.map(d => (
                    <MenuItem key={d.departmentId} value={d.departmentId}>{d.departmentName}</MenuItem>
                  ))}
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField label="Password" type="password" fullWidth {...register('password')} error={!!errors.password} helperText={errors.password?.message} />
              </Grid>
              <Grid item xs={12}>
                <Button type="submit" variant="contained" fullWidth size="large" disabled={loading}>
                  {loading ? 'Submitting…' : 'Submit Registration'}
                </Button>
              </Grid>
              <Grid item xs={12}>
                <Button component={RouterLink} to="/login" variant="outlined" fullWidth>Back to Login</Button>
              </Grid>
            </Grid>
          </Box>
        </CardContent>
      </Card>
    </Box>
  )
}

export default RegisterDoctor
