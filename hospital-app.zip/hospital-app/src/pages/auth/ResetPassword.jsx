import React, { useState } from 'react'
import { Box, Card, CardContent, Typography, TextField, Button, Alert } from '@mui/material'
import { MedicalServices } from '@mui/icons-material'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useNavigate, Link as RouterLink, useSearchParams } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { showSnackbar } from '../../redux/slices/uiSlice'
import authService from '../../services/authService'

const schema = yup.object({
  password: yup.string().min(6, 'Min 6 characters').required('Password is required'),
  confirmPassword: yup.string().oneOf([yup.ref('password')], 'Passwords must match').required('Confirm password'),
})

function ResetPassword() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const [loading, setLoading] = useState(false)
  const token = searchParams.get('token')

  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: yupResolver(schema) })

  const onSubmit = async (data) => {
    setLoading(true)
    try {
      await authService.resetPassword({ token, password: data.password })
      dispatch(showSnackbar({ message: 'Password reset successfully!', severity: 'success' }))
      navigate('/login')
    } catch {
      dispatch(showSnackbar({ message: 'Failed to reset password.', severity: 'error' }))
    } finally {
      setLoading(false)
    }
  }

  return (
    <Box sx={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', bgcolor: 'background.default', p: 2 }}>
      <Card sx={{ width: '100%', maxWidth: 440 }}>
        <CardContent sx={{ p: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 3 }}>
            <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: 'primary.main', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <MedicalServices sx={{ color: 'white', fontSize: 20 }} />
            </Box>
            <Typography variant="h5" fontWeight={700}>Reset Password</Typography>
          </Box>

          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            Enter your new password below.
          </Typography>

          <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
            <TextField
              label="New Password" type="password" fullWidth
              {...register('password')} error={!!errors.password} helperText={errors.password?.message}
            />
            <TextField
              label="Confirm Password" type="password" fullWidth
              {...register('confirmPassword')} error={!!errors.confirmPassword} helperText={errors.confirmPassword?.message}
            />
            <Button type="submit" variant="contained" fullWidth size="large" disabled={loading}>
              {loading ? 'Resetting…' : 'Reset Password'}
            </Button>
            <Button component={RouterLink} to="/login" variant="outlined" fullWidth>Back to Login</Button>
          </Box>
        </CardContent>
      </Card>
    </Box>
  )
}

export default ResetPassword
