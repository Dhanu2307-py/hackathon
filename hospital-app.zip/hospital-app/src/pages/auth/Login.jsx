import React, { useState } from 'react'
import {
  Box, Card, CardContent, Typography, TextField, Button,
  Checkbox, FormControlLabel, Link, InputAdornment, IconButton, Divider, Alert
} from '@mui/material'
import { Visibility, VisibilityOff, MedicalServices, Favorite } from '@mui/icons-material'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useDispatch } from 'react-redux'
import { useNavigate, Link as RouterLink } from 'react-router-dom'
import { loginSuccess } from '../../redux/slices/authSlice'
import { showSnackbar } from '../../redux/slices/uiSlice'
import authService from '../../services/authService'

const schema = yup.object({
  email: yup.string().email('Invalid email').required('Email is required'),
  password: yup.string().min(4, 'Min 4 characters').required('Password is required'),
})

function Login() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: yupResolver(schema) })

  const onSubmit = async (data) => {
    setLoading(true)
    setError('')
    try {
      // authService.login returns { token, role, user }
      const result = await authService.login(data)
      dispatch(loginSuccess({ token: result.token, user: result.user, role: result.role }))
      dispatch(showSnackbar({ message: `Welcome back, ${result.user?.name || 'User'}!`, severity: 'success' }))
      navigate('/dashboard')
    } catch (err) {
      const message = err.response?.data?.message || 'Login failed. Please check your credentials.'
      setError(message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Box sx={{ minHeight: '100vh', display: 'flex', bgcolor: 'background.default' }}>
      {/* Left panel */}
      <Box sx={{
        flex: 1, display: { xs: 'none', md: 'flex' }, flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        background: 'linear-gradient(135deg, #1E293B 0%, #0F172A 100%)', p: 6, gap: 4,
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
          <Box sx={{ width: 56, height: 56, borderRadius: 3, bgcolor: 'primary.main', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <MedicalServices sx={{ color: 'white', fontSize: 30 }} />
          </Box>
          <Typography variant="h4" sx={{ color: 'white', fontWeight: 800 }}>MediCare</Typography>
        </Box>
        <Box sx={{ width: 280, height: 280, borderRadius: 4, bgcolor: 'rgba(249,115,22,0.1)', border: '2px solid rgba(249,115,22,0.2)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2 }}>
          <Favorite sx={{ fontSize: 72, color: '#F97316', opacity: 0.8 }} />
          <Typography sx={{ color: '#94A3B8', fontSize: '0.85rem', textAlign: 'center', px: 3 }}>
            Comprehensive healthcare management at your fingertips
          </Typography>
        </Box>
        <Box sx={{ textAlign: 'center' }}>
          <Typography variant="h5" sx={{ color: 'white', fontWeight: 700, mb: 1 }}>Welcome to MediCare</Typography>
          <Typography variant="body2" sx={{ color: '#94A3B8', maxWidth: 320 }}>
            A complete hospital appointment and patient management platform.
          </Typography>
        </Box>
      </Box>

      {/* Right panel */}
      <Box sx={{ flex: { xs: 1, md: '0 0 460px' }, display: 'flex', alignItems: 'center', justifyContent: 'center', p: { xs: 2, sm: 4 } }}>
        <Card sx={{ width: '100%', maxWidth: 400 }}>
          <CardContent sx={{ p: 4 }}>
            <Box sx={{ mb: 4 }}>
              <Typography variant="h5" fontWeight={700} gutterBottom>Sign in</Typography>
              <Typography variant="body2" color="text.secondary">Enter your credentials to access your account</Typography>
            </Box>

            {error && <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>{error}</Alert>}

            <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
              <TextField label="Email Address" type="email" fullWidth {...register('email')} error={!!errors.email} helperText={errors.email?.message} />
              <TextField
                label="Password" type={showPass ? 'text' : 'password'} fullWidth
                {...register('password')} error={!!errors.password} helperText={errors.password?.message}
                InputProps={{ endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={() => setShowPass(p => !p)} edge="end" size="small">
                      {showPass ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                )}}
              />
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <FormControlLabel control={<Checkbox size="small" color="primary" />} label={<Typography variant="body2">Remember me</Typography>} />
                <Link component={RouterLink} to="/forgot-password" variant="body2" color="primary">Forgot password?</Link>
              </Box>
              <Button type="submit" variant="contained" fullWidth size="large" disabled={loading} sx={{ mt: 1 }}>
                {loading ? 'Signing in…' : 'Sign In'}
              </Button>
            </Box>

            <Divider sx={{ my: 3 }}><Typography variant="caption" color="text.secondary">or register as</Typography></Divider>
            <Box sx={{ display: 'flex', gap: 2 }}>
              <Button component={RouterLink} to="/register/patient" variant="outlined" fullWidth size="small">Patient</Button>
              <Button component={RouterLink} to="/register/doctor" variant="outlined" fullWidth size="small">Doctor</Button>
            </Box>
          </CardContent>
        </Card>
      </Box>
    </Box>
  )
}

export default Login
