import React from 'react'
import { Box, Typography, Button } from '@mui/material'
import { Home, ArrowBack } from '@mui/icons-material'
import { useNavigate } from 'react-router-dom'

function NotFound() {
  const navigate = useNavigate()

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        bgcolor: 'background.default',
        p: 4,
        textAlign: 'center',
      }}
    >
      <Typography
        variant="h1"
        sx={{
          fontSize: { xs: '6rem', sm: '10rem' },
          fontWeight: 800,
          color: 'primary.main',
          lineHeight: 1,
          mb: 2,
          opacity: 0.8,
        }}
      >
        404
      </Typography>

      <Typography variant="h5" fontWeight={700} gutterBottom>
        Page Not Found
      </Typography>
      <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 380, mb: 4 }}>
        The page you're looking for doesn't exist or has been moved. Let's get you back on track.
      </Typography>

      <Box sx={{ display: 'flex', gap: 2 }}>
        <Button variant="contained" startIcon={<Home />} onClick={() => navigate('/dashboard')}>
          Go to Dashboard
        </Button>
        <Button variant="outlined" startIcon={<ArrowBack />} onClick={() => navigate(-1)}>
          Go Back
        </Button>
      </Box>
    </Box>
  )
}

export default NotFound
