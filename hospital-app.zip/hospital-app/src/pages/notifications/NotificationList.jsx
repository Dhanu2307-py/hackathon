import React, { useEffect } from 'react'
import {
  Box, Card, CardContent, Typography, Button, Chip, IconButton, Tooltip
} from '@mui/material'
import { DoneAll, MarkEmailRead, Notifications } from '@mui/icons-material'
import { useDispatch, useSelector } from 'react-redux'
import { setNotifications, markAsRead, markAllRead } from '../../redux/slices/notificationSlice'
import { showSnackbar } from '../../redux/slices/uiSlice'
import { PageHeader, EmptyState } from '../../components/Loader'
import { notificationService } from '../../services/otherServices'

function NotificationList() {
  const dispatch = useDispatch()
  const { items } = useSelector(s => s.notifications)
  const { user } = useSelector(s => s.auth)

  useEffect(() => {
    if (!user?.id) return
    // GET /notifications?userId={userId}
    // NotificationDTO: { id, userId, userRole, title, message, type, referenceId, referenceType, isRead, createdAt }
    notificationService.getAll(user.id)
      .then(data => dispatch(setNotifications(Array.isArray(data) ? data : [])))
      .catch(() => dispatch(showSnackbar({ message: 'Failed to load notifications', severity: 'error' })))
  }, [user?.id])

  const handleMarkRead = async (notifId) => {
    try {
      // PUT /notifications/{id}/read
      await notificationService.markRead(notifId)
      dispatch(markAsRead(notifId))
    } catch {
      dispatch(showSnackbar({ message: 'Failed to update notification', severity: 'error' }))
    }
  }

  const handleMarkAllRead = async () => {
    try {
      // PUT /notifications/read-all?userId={userId}
      await notificationService.markAllRead(user.id)
      dispatch(markAllRead())
      dispatch(showSnackbar({ message: 'All notifications marked as read', severity: 'success' }))
    } catch {
      dispatch(showSnackbar({ message: 'Failed to update notifications', severity: 'error' }))
    }
  }

  // Backend uses isRead (boolean), map to read for Redux consistency
  const normalised = items.map(n => ({
    ...n,
    read: n.isRead ?? n.read ?? false,
  }))

  const unread = normalised.filter(n => !n.read).length

  return (
    <Box>
      <PageHeader
        title="Notifications"
        subtitle={`${unread} unread notification${unread !== 1 ? 's' : ''}`}
        action={
          unread > 0 && (
            <Button variant="outlined" startIcon={<DoneAll />} onClick={handleMarkAllRead}>
              Mark All Read
            </Button>
          )
        }
      />

      {normalised.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState icon={<Notifications />} title="No notifications" subtitle="You're all caught up!" />
          </CardContent>
        </Card>
      ) : (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {normalised.map(n => (
            <Card
              key={n.id}
              sx={{
                border: n.read ? '1px solid transparent' : '1px solid #FED7AA',
                bgcolor: n.read ? 'background.paper' : (theme => theme.palette.mode === 'dark' ? 'rgba(249,115,22,0.05)' : '#FFF7ED'),
                transition: 'all 0.2s',
              }}
            >
              <CardContent sx={{ p: 2.5, '&:last-child': { pb: 2.5 } }}>
                <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2 }}>
                  <Box sx={{
                    width: 40, height: 40, borderRadius: 2, flexShrink: 0,
                    bgcolor: n.read ? 'action.hover' : '#FFF7ED',
                    border: `1px solid ${n.read ? 'transparent' : '#FED7AA'}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <Notifications sx={{ fontSize: 18, color: n.read ? 'text.secondary' : '#F97316' }} />
                  </Box>

                  <Box sx={{ flex: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                      {/* NotificationType enum shown as chip */}
                      {n.type && (
                        <Chip
                          label={n.type.replace(/_/g, ' ')}
                          size="small"
                          color={n.read ? 'default' : 'primary'}
                          sx={{ height: 18, fontSize: '0.65rem', fontWeight: 700 }}
                        />
                      )}
                    </Box>
                    {n.title && (
                      <Typography variant="body2" fontWeight={600} sx={{ mb: 0.5 }}>
                        {n.title}
                      </Typography>
                    )}
                    <Typography variant="body2" sx={{ lineHeight: 1.6, color: n.read ? 'text.secondary' : 'text.primary', fontWeight: n.read ? 400 : 400 }}>
                      {n.message}
                    </Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: 'block' }}>
                      {n.createdAt ? new Date(n.createdAt).toLocaleString() : ''}
                    </Typography>
                  </Box>

                  {!n.read && (
                    <Tooltip title="Mark as read">
                      <IconButton size="small" onClick={() => handleMarkRead(n.id)} sx={{ color: 'primary.main', flexShrink: 0 }}>
                        <MarkEmailRead fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  )}
                </Box>
              </CardContent>
            </Card>
          ))}
        </Box>
      )}
    </Box>
  )
}

export default NotificationList
