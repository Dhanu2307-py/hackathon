import React, { useState } from 'react'
import {
  Grid, Card, CardContent, Typography, Box, Button, Switch,
  MenuItem, TextField, useTheme
} from '@mui/material'
import { Save, Logout, Notifications, Language, Palette, LightMode, DarkMode } from '@mui/icons-material'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { PageHeader, ConfirmDialog } from '../../components/Loader'
import { showSnackbar, setThemeMode } from '../../redux/slices/uiSlice'
import { logout } from '../../redux/slices/authSlice'
import { markAllRead } from '../../redux/slices/notificationSlice'
import { notificationService } from '../../services/otherServices'

function SettingsSection({ icon, title, color = '#F97316', bg, children }) {
  const muiTheme = useTheme()
  const isDark = muiTheme.palette.mode === 'dark'
  const defaultBg = isDark ? 'rgba(249,115,22,0.1)' : '#FFF7ED'
  return (
    <Card sx={{ mb: 3 }}>
      <CardContent sx={{ p: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2.5 }}>
          <Box sx={{
            width: 36, height: 36, borderRadius: 2,
            bgcolor: bg || defaultBg,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            {React.cloneElement(icon, { sx: { color, fontSize: 20 } })}
          </Box>
          <Typography variant="h6" fontWeight={600}>{title}</Typography>
        </Box>
        {children}
      </CardContent>
    </Card>
  )
}

function Settings() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const muiTheme = useTheme()
  const isDark = muiTheme.palette.mode === 'dark'
  const currentMode = useSelector(s => s.ui.themeMode)
  const { user } = useSelector(s => s.auth)

  const [logoutConfirm, setLogoutConfirm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [language, setLanguage] = useState('en')

  const [notifSettings, setNotifSettings] = useState({
    emailNotifications:   true,
    appointmentReminders: true,
    paymentAlerts:        true,
    systemUpdates:        false,
  })

  const toggleNotif = key => setNotifSettings(p => ({ ...p, [key]: !p[key] }))

  const handleThemeChange = value => dispatch(setThemeMode(value))

  const handleSave = async () => {
    setSaving(true)
    await new Promise(r => setTimeout(r, 600))
    dispatch(showSnackbar({ message: 'Settings saved successfully', severity: 'success' }))
    setSaving(false)
  }

  const handleLogout = async () => {
    // Mark all notifications read before logout so count resets cleanly
    try {
      if (user?.id) {
        // PUT /notifications/read-all?userId={userId}
        await notificationService.markAllRead(user.id)
        dispatch(markAllRead())
      }
    } catch { /* non-blocking */ }
    dispatch(logout())
    navigate('/login')
  }

  const dividerColor = isDark ? 'rgba(148,163,184,0.12)' : '#F1F5F9'

  return (
    <Box>
      <PageHeader title="Settings" subtitle="Manage your account preferences" />

      <Grid container spacing={3} sx={{ maxWidth: 800 }}>
        <Grid item xs={12}>

          {/* Notification Preferences */}
          <SettingsSection icon={<Notifications />} title="Notification Preferences">
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {[
                { key: 'emailNotifications',   label: 'Email Notifications',   desc: 'Receive notifications via email' },
                { key: 'appointmentReminders', label: 'Appointment Reminders', desc: 'Get reminded before appointments' },
                { key: 'paymentAlerts',        label: 'Payment Alerts',        desc: 'Notifications for payment activity' },
                { key: 'systemUpdates',        label: 'System Updates',        desc: 'Announcements and system news' },
              ].map(({ key, label, desc }) => (
                <Box key={key} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', py: 1.5, borderBottom: `1px solid ${dividerColor}` }}>
                  <Box>
                    <Typography variant="body2" fontWeight={500}>{label}</Typography>
                    <Typography variant="caption" color="text.secondary">{desc}</Typography>
                  </Box>
                  <Switch checked={notifSettings[key]} onChange={() => toggleNotif(key)} color="primary" size="small" />
                </Box>
              ))}
            </Box>
          </SettingsSection>

          {/* Theme Settings */}
          <SettingsSection
            icon={<Palette />} title="Theme Settings" color="#8B5CF6"
            bg={isDark ? 'rgba(139,92,246,0.12)' : '#F5F3FF'}
          >
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <Typography variant="body2" color="text.secondary">
                Choose your preferred display theme. Changes apply instantly.
              </Typography>
              <Box sx={{ display: 'flex', gap: 2 }}>
                {[
                  { value: 'light', label: 'Light', icon: <LightMode />, desc: 'Clean white interface' },
                  { value: 'dark',  label: 'Dark',  icon: <DarkMode />,  desc: 'Easy on the eyes' },
                ].map(opt => {
                  const selected = currentMode === opt.value
                  return (
                    <Box
                      key={opt.value}
                      onClick={() => handleThemeChange(opt.value)}
                      sx={{
                        flex: 1, p: 2, borderRadius: 3, cursor: 'pointer', transition: 'all 0.15s',
                        border: selected ? '2px solid #F97316' : `2px solid ${dividerColor}`,
                        bgcolor: selected
                          ? (isDark ? 'rgba(249,115,22,0.08)' : '#FFF7ED')
                          : (isDark ? 'rgba(148,163,184,0.05)' : '#F8FAFC'),
                        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1,
                        '&:hover': { borderColor: '#F97316' },
                      }}
                    >
                      <Box sx={{ color: selected ? 'primary.main' : 'text.secondary' }}>{opt.icon}</Box>
                      <Typography variant="body2" fontWeight={selected ? 700 : 500} color={selected ? 'primary.main' : 'text.primary'}>
                        {opt.label}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">{opt.desc}</Typography>
                    </Box>
                  )
                })}
              </Box>
              <Typography variant="caption" color="text.secondary">
                💡 You can also toggle the theme using the {isDark ? '☀️' : '🌙'} icon in the top navigation bar.
              </Typography>
            </Box>
          </SettingsSection>

          {/* Language */}
          <SettingsSection
            icon={<Language />} title="Language" color="#2563EB"
            bg={isDark ? 'rgba(37,99,235,0.12)' : '#EFF6FF'}
          >
            <TextField select label="Display Language" value={language}
              onChange={e => setLanguage(e.target.value)} sx={{ minWidth: 240 }} size="small">
              <MenuItem value="en">English</MenuItem>
              <MenuItem value="hi">Hindi</MenuItem>
              <MenuItem value="es">Spanish</MenuItem>
              <MenuItem value="fr">French</MenuItem>
            </TextField>
          </SettingsSection>

          {/* Actions */}
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            <Button variant="contained" startIcon={<Save />} onClick={handleSave} disabled={saving}>
              {saving ? 'Saving…' : 'Save Settings'}
            </Button>
            <Button variant="outlined" color="error" startIcon={<Logout />} onClick={() => setLogoutConfirm(true)}>
              Logout
            </Button>
          </Box>
        </Grid>
      </Grid>

      <ConfirmDialog
        open={logoutConfirm}
        onClose={() => setLogoutConfirm(false)}
        onConfirm={handleLogout}
        title="Confirm Logout"
        message="Are you sure you want to log out of your account?"
        confirmLabel="Logout"
        confirmColor="error"
      />
    </Box>
  )
}

export default Settings
