import React, { useState } from 'react'
import {
  Grid, Card, CardContent, Typography, Box, Button, TextField,
  Avatar, Divider, Dialog, DialogTitle, DialogContent, DialogActions
} from '@mui/material'
import { Edit, Save, LockReset, CameraAlt } from '@mui/icons-material'
import { useSelector } from 'react-redux'
import { useDispatch } from 'react-redux'
import { PageHeader } from '../../components/Loader'
import { showSnackbar } from '../../redux/slices/uiSlice'
import authService from '../../services/authService'

function InfoRow({ label, value }) {
  return (
    <Box sx={{ display: 'flex', py: 1.2, borderBottom: '1px solid', borderColor: 'divider' }}>
      <Typography variant="body2" color="text.secondary" sx={{ width: 140, flexShrink: 0 }}>{label}</Typography>
      <Typography variant="body2" fontWeight={500}>{value || '—'}</Typography>
    </Box>
  )
}

function Profile() {
  const { user, role } = useSelector(s => s.auth)
  const dispatch = useDispatch()
  const [editing, setEditing] = useState(false)
  const [pwDialog, setPwDialog] = useState(false)
  const [saving, setSaving] = useState(false)

  // Profile data is read from Redux auth state (set on login)
  // The Auth Service GET /auth/profile returns { id, name, email, role, status, phoneNumber }
  const [formData, setFormData] = useState({
    name:        user?.name        || '',
    email:       user?.email       || '',
    phoneNumber: user?.phoneNumber || '',
  })
  const [pwData, setPwData] = useState({ current: '', newPw: '', confirm: '' })

  const handleSave = async () => {
    setSaving(true)
    try {
      // Auth Service does not expose a PUT /auth/profile endpoint in the provided spec.
      // Profile updates for patients go through Patient Service PUT /api/patients/{id}.
      // For now, show a message directing to the correct service.
      dispatch(showSnackbar({ message: 'To update patient details, use the Patients module.', severity: 'info' }))
      setEditing(false)
    } finally {
      setSaving(false)
    }
  }

  const handleChangePw = async () => {
    if (pwData.newPw !== pwData.confirm) {
      dispatch(showSnackbar({ message: 'Passwords do not match', severity: 'error' }))
      return
    }
    if (pwData.newPw.length < 6) {
      dispatch(showSnackbar({ message: 'Password must be at least 6 characters', severity: 'error' }))
      return
    }
    // Password change would go through Auth Service — endpoint not in spec
    dispatch(showSnackbar({ message: 'Password change feature requires backend endpoint.', severity: 'info' }))
    setPwDialog(false)
    setPwData({ current: '', newPw: '', confirm: '' })
  }

  return (
    <Box>
      <PageHeader title="My Profile" subtitle="Your account information" />

      <Grid container spacing={3}>
        {/* Avatar card */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent sx={{ p: 4, textAlign: 'center' }}>
              <Box sx={{ position: 'relative', display: 'inline-block', mb: 2 }}>
                <Avatar sx={{ width: 96, height: 96, mx: 'auto', fontSize: '2.2rem', bgcolor: 'primary.main' }}>
                  {user?.name?.charAt(0) || 'U'}
                </Avatar>
              </Box>

              <Typography variant="h6" fontWeight={700}>{user?.name || 'User'}</Typography>
              <Typography variant="body2" color="text.secondary">{user?.email}</Typography>
              <Box sx={{ mt: 1.5, px: 2, py: 0.5, bgcolor: 'action.hover', borderRadius: 2, display: 'inline-block' }}>
                <Typography variant="caption" sx={{ color: 'primary.main', fontWeight: 600 }}>{role}</Typography>
              </Box>

              <Divider sx={{ my: 3 }} />

              <InfoRow label="Email" value={user?.email} />
              <InfoRow label="Phone" value={user?.phoneNumber} />
              <InfoRow label="Status" value={user?.status} />
              <InfoRow label="Role" value={role} />

              <Divider sx={{ my: 3 }} />

              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                <Button variant="outlined" startIcon={<LockReset />} fullWidth onClick={() => setPwDialog(true)}>
                  Change Password
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Info card */}
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" fontWeight={600} sx={{ mb: 3 }}>Account Information</Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2, lineHeight: 1.8 }}>
                Your account is managed by the Auth Service. Profile details (name, phone, etc.) are
                stored in your respective service module:
                <br />• <strong>Patients</strong> → use the Patients module to update your full profile
                <br />• <strong>Doctors</strong> → your profile is managed in the Doctor Service
                <br />• <strong>Admin</strong> → contact your system administrator
              </Typography>

              <Grid container spacing={2.5}>
                <Grid item xs={12} sm={6}>
                  <TextField label="Full Name" fullWidth value={formData.name} disabled />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Email Address" fullWidth value={formData.email} disabled />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Phone Number" fullWidth value={formData.phoneNumber} disabled />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField label="Role" fullWidth value={role || ''} disabled />
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Change Password Dialog */}
      <Dialog open={pwDialog} onClose={() => setPwDialog(false)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 600 }}>Change Password</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2.5, pt: '16px !important' }}>
          <TextField label="Current Password" type="password" fullWidth value={pwData.current} onChange={e => setPwData(p => ({ ...p, current: e.target.value }))} />
          <TextField label="New Password" type="password" fullWidth value={pwData.newPw} onChange={e => setPwData(p => ({ ...p, newPw: e.target.value }))} />
          <TextField label="Confirm New Password" type="password" fullWidth value={pwData.confirm} onChange={e => setPwData(p => ({ ...p, confirm: e.target.value }))} />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setPwDialog(false)} variant="outlined">Cancel</Button>
          <Button onClick={handleChangePw} variant="contained">Update Password</Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default Profile
