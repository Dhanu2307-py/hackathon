import React, { useState, useEffect } from 'react'
import {
  Card, CardContent, Box, Button, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, TablePagination,
  IconButton, Tooltip, Avatar, Chip
} from '@mui/material'
import { CheckCircle, Cancel, EventAvailable, LocalHospital } from '@mui/icons-material'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { PageHeader, SearchBar, EmptyState, ConfirmDialog } from '../../components/Loader'
import StatusChip from '../../components/StatusChip'
import { showSnackbar } from '../../redux/slices/uiSlice'
import doctorService from '../../services/doctorService'

function DoctorList() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [doctors, setDoctors] = useState([])
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(10)
  const [loading, setLoading] = useState(true)
  const [confirmAction, setConfirmAction] = useState(null) // { id, type }

  const fetch = async () => {
    setLoading(true)
    try {
      // GET /doctors  → List<DoctorResponse>
      const data = await doctorService.getAll()
      setDoctors(Array.isArray(data) ? data : [])
    } catch {
      dispatch(showSnackbar({ message: 'Failed to load doctors', severity: 'error' }))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetch() }, [])

  const handleConfirm = async () => {
    try {
      if (confirmAction.type === 'approve') {
        // PUT /admin/doctors/{id}/approve
        await doctorService.approve(confirmAction.id)
      } else {
        // PUT /admin/doctors/{id}/reject
        await doctorService.reject(confirmAction.id)
      }
      dispatch(showSnackbar({ message: `Doctor ${confirmAction.type}d successfully`, severity: 'success' }))
      setConfirmAction(null)
      fetch()
    } catch {
      dispatch(showSnackbar({ message: 'Action failed', severity: 'error' }))
    }
  }

  const filtered = doctors.filter(d =>
    !search ||
    d.doctorName?.toLowerCase().includes(search.toLowerCase()) ||
    d.specialization?.toLowerCase().includes(search.toLowerCase()) ||
    d.departmentName?.toLowerCase().includes(search.toLowerCase())
  )

  const paged = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)

  return (
    <Box>
      <PageHeader title="Doctors" subtitle={`${doctors.length} doctors registered`} />

      <Card>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ mb: 2 }}>
            <SearchBar
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(0) }}
              placeholder="Search by name, specialization or department…"
            />
          </Box>

          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  {['#', 'Doctor', 'Department', 'Specialization', 'Exp.', 'Approval', 'Status', 'Actions'].map(h => (
                    <TableCell key={h} sx={{ fontWeight: 600, color: 'text.secondary', fontSize: '0.8rem', whiteSpace: 'nowrap' }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {loading
                  ? Array.from({ length: 5 }).map((_, i) => (
                      <TableRow key={i}>{Array.from({ length: 8 }).map((_, j) => (
                        <TableCell key={j}><Box sx={{ height: 20, bgcolor: 'action.hover', borderRadius: 1 }} /></TableCell>
                      ))}</TableRow>
                    ))
                  : paged.length === 0
                  ? <TableRow><TableCell colSpan={8}><EmptyState icon={<LocalHospital />} title="No doctors found" /></TableCell></TableRow>
                  : paged.map((d, idx) => (
                    <TableRow key={d.doctorId} hover>
                      <TableCell sx={{ color: 'text.secondary', fontSize: '0.8rem' }}>{page * rowsPerPage + idx + 1}</TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                          <Avatar sx={{ width: 32, height: 32, fontSize: '0.85rem', bgcolor: '#2563EB' }}>
                            {d.doctorName?.charAt(0)}
                          </Avatar>
                          <Box>
                            <Box sx={{ fontWeight: 500, fontSize: '0.875rem' }}>{d.doctorName}</Box>
                            <Box sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>{d.email}</Box>
                          </Box>
                        </Box>
                      </TableCell>
                      <TableCell>{d.departmentName}</TableCell>
                      <TableCell>{d.specialization}</TableCell>
                      <TableCell>{d.experience} yrs</TableCell>
                      <TableCell>
                        {/* approvalStatus: PENDING | APPROVED | REJECTED */}
                        <StatusChip status={d.approvalStatus} />
                      </TableCell>
                      <TableCell>
                        {/* status: ACTIVE | INACTIVE | ON_LEAVE */}
                        <StatusChip status={d.status} />
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: 0.5 }}>
                          <Tooltip title="Availability">
                            <IconButton size="small" color="info" onClick={() => navigate(`/doctors/${d.doctorId}/availability`)}>
                              <EventAvailable fontSize="small" />
                            </IconButton>
                          </Tooltip>
                          {d.approvalStatus === 'PENDING' && (
                            <>
                              <Tooltip title="Approve">
                                <IconButton size="small" color="success" onClick={() => setConfirmAction({ id: d.doctorId, type: 'approve' })}>
                                  <CheckCircle fontSize="small" />
                                </IconButton>
                              </Tooltip>
                              <Tooltip title="Reject">
                                <IconButton size="small" color="error" onClick={() => setConfirmAction({ id: d.doctorId, type: 'reject' })}>
                                  <Cancel fontSize="small" />
                                </IconButton>
                              </Tooltip>
                            </>
                          )}
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </TableContainer>

          <TablePagination
            component="div" count={filtered.length} page={page}
            onPageChange={(_, p) => setPage(p)} rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(+e.target.value); setPage(0) }}
            rowsPerPageOptions={[5, 10, 25]}
          />
        </CardContent>
      </Card>

      <ConfirmDialog
        open={!!confirmAction}
        onClose={() => setConfirmAction(null)}
        onConfirm={handleConfirm}
        title={confirmAction?.type === 'approve' ? 'Approve Doctor' : 'Reject Doctor'}
        message={`Are you sure you want to ${confirmAction?.type} this doctor?`}
        confirmLabel={confirmAction?.type === 'approve' ? 'Approve' : 'Reject'}
        confirmColor={confirmAction?.type === 'approve' ? 'success' : 'error'}
      />
    </Box>
  )
}

export default DoctorList
