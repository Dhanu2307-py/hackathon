import React, { useState, useEffect } from 'react'
import {
  Box, Card, CardContent, Typography, Button, Grid, Chip,
  Divider, TextField, Dialog, DialogTitle, DialogContent,
  DialogActions, MenuItem
} from '@mui/material'
import { ArrowBack, Add, Delete } from '@mui/icons-material'
import { useParams, useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { PageHeader, Loader, EmptyState } from '../../components/Loader'
import { showSnackbar } from '../../redux/slices/uiSlice'
import doctorService from '../../services/doctorService'

// DayOfWeek enum from Doctor Service
const DAYS = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY']

const defaultForm = { dayOfWeek: '', startTime: '', endTime: '', slotDuration: 30 }

function DoctorAvailability() {
  const { id } = useParams() // doctorId
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [slots, setSlots] = useState([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [form, setForm] = useState(defaultForm)
  const [saving, setSaving] = useState(false)

  const loadAvailability = async () => {
    setLoading(true)
    try {
      // GET /availability/doctor/{doctorId}
      // Response: List<AvailabilityResponse> { availabilityId, doctorName, dayOfWeek,
      //           startTime, endTime, slotDuration, available }
      const data = await doctorService.getAvailability(id)
      setSlots(Array.isArray(data) ? data : [])
    } catch {
      dispatch(showSnackbar({ message: 'Failed to load availability', severity: 'error' }))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { loadAvailability() }, [id])

  const handleAdd = async () => {
    if (!form.dayOfWeek || !form.startTime || !form.endTime) {
      dispatch(showSnackbar({ message: 'Please fill all fields', severity: 'warning' }))
      return
    }
    setSaving(true)
    try {
      // POST /availability
      // Request: { doctorId, dayOfWeek, startTime, endTime, slotDuration }
      await doctorService.addAvailability({
        doctorId: Number(id),
        dayOfWeek: form.dayOfWeek,
        startTime: form.startTime,
        endTime: form.endTime,
        slotDuration: Number(form.slotDuration),
      })
      dispatch(showSnackbar({ message: 'Availability added', severity: 'success' }))
      setDialogOpen(false)
      setForm(defaultForm)
      loadAvailability()
    } catch {
      dispatch(showSnackbar({ message: 'Failed to add availability', severity: 'error' }))
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (availabilityId) => {
    try {
      // DELETE /availability/{availabilityId}
      await doctorService.deleteAvailability(availabilityId)
      dispatch(showSnackbar({ message: 'Slot removed', severity: 'success' }))
      loadAvailability()
    } catch {
      dispatch(showSnackbar({ message: 'Failed to remove slot', severity: 'error' }))
    }
  }

  if (loading) return <Loader />

  // Group slots by day
  const byDay = DAYS.reduce((acc, day) => {
    acc[day] = slots.filter(s => s.dayOfWeek === day)
    return acc
  }, {})

  return (
    <Box>
      <PageHeader
        title="Doctor Availability"
        subtitle="Manage weekly schedule and time slots"
        action={
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Button variant="outlined" startIcon={<ArrowBack />} onClick={() => navigate('/doctors')}>Back</Button>
            <Button variant="contained" startIcon={<Add />} onClick={() => setDialogOpen(true)}>Add Slot</Button>
          </Box>
        }
      />

      {slots.length === 0 ? (
        <Card>
          <CardContent>
            <EmptyState title="No availability set" subtitle="Add availability slots using the button above." />
          </CardContent>
        </Card>
      ) : (
        <Grid container spacing={2.5}>
          {DAYS.map(day => {
            const daySlots = byDay[day]
            if (daySlots.length === 0) return null
            return (
              <Grid item xs={12} sm={6} md={4} key={day}>
                <Card>
                  <CardContent sx={{ p: 3 }}>
                    <Typography variant="h6" fontWeight={600} fontSize="0.95rem" sx={{ mb: 2 }}>{day}</Typography>
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                      {daySlots.map(slot => (
                        <Box key={slot.availabilityId} sx={{
                          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                          p: 1.5, borderRadius: 2, bgcolor: 'action.hover',
                        }}>
                          <Box>
                            <Typography variant="body2" fontWeight={500}>
                              {slot.startTime} – {slot.endTime}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {slot.slotDuration} min slots
                            </Typography>
                          </Box>
                          <Button
                            size="small" color="error"
                            onClick={() => handleDelete(slot.availabilityId)}
                            sx={{ minWidth: 0, p: 0.5 }}
                          >
                            <Delete fontSize="small" />
                          </Button>
                        </Box>
                      ))}
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            )
          })}
        </Grid>
      )}

      {/* Add Slot Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle fontWeight={600}>Add Availability Slot</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2.5, pt: '16px !important' }}>
          <TextField
            select label="Day of Week" value={form.dayOfWeek} fullWidth
            onChange={e => setForm(p => ({ ...p, dayOfWeek: e.target.value }))}
          >
            {DAYS.map(d => <MenuItem key={d} value={d}>{d}</MenuItem>)}
          </TextField>
          <TextField
            label="Start Time" type="time" fullWidth value={form.startTime}
            onChange={e => setForm(p => ({ ...p, startTime: e.target.value }))}
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            label="End Time" type="time" fullWidth value={form.endTime}
            onChange={e => setForm(p => ({ ...p, endTime: e.target.value }))}
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            label="Slot Duration (minutes)" type="number" fullWidth value={form.slotDuration}
            onChange={e => setForm(p => ({ ...p, slotDuration: e.target.value }))}
            inputProps={{ min: 10, max: 120, step: 5 }}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDialogOpen(false)} variant="outlined">Cancel</Button>
          <Button onClick={handleAdd} variant="contained" disabled={saving}>
            {saving ? 'Adding…' : 'Add Slot'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default DoctorAvailability
