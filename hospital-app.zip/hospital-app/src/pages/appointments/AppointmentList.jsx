import React, { useState, useEffect } from 'react'
import {
  Card, CardContent, Box, Button, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, TablePagination,
  IconButton, Tooltip, MenuItem, TextField
} from '@mui/material'
import { Add, Visibility, CheckCircle, Cancel, TaskAlt, CalendarMonth } from '@mui/icons-material'
import { useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { PageHeader, SearchBar, EmptyState } from '../../components/Loader'
import StatusChip from '../../components/StatusChip'
import { showSnackbar } from '../../redux/slices/uiSlice'
import appointmentService from '../../services/appointmentService'

// AppointmentStatus enum values from backend
const STATUS_OPTIONS = ['All', 'PENDING', 'CONFIRMED', 'COMPLETED', 'CANCELLED', 'PENDING_PAYMENT', 'WAITING_FOR_DOCTOR', 'RESCHEDULE_REQUESTED', 'REFUNDED']

function AppointmentList() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { user, role } = useSelector(s => s.auth)
  const [appointments, setAppointments] = useState([])
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('All')
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(10)
  const [loading, setLoading] = useState(true)

  const fetchAppointments = async () => {
    setLoading(true)
    try {
      let data = []
      // Fetch based on role
      if (role === 'PATIENT' && user?.patientProfileId) {
        // GET /appointments/patient/{profileId}
        data = await appointmentService.getByPatient(user.patientProfileId)
      } else if (role === 'DOCTOR' && user?.doctorId) {
        // GET /appointments/doctor/{doctorId}
        data = await appointmentService.getByDoctor(user.doctorId)
      } else {
        // ADMIN — no generic "get all" endpoint in backend, fetch by patient 0 or handle gracefully
        // For now fetch by doctor as fallback if available
        dispatch(showSnackbar({ message: 'Admin view: use patient or doctor ID to filter', severity: 'info' }))
        data = []
      }
      setAppointments(Array.isArray(data) ? data : [])
    } catch {
      dispatch(showSnackbar({ message: 'Failed to load appointments', severity: 'error' }))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchAppointments() }, [])

  const filtered = appointments.filter(a => {
    const matchStatus = statusFilter === 'All' || a.status === statusFilter
    return matchStatus
  })

  const paged = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)

  return (
    <Box>
      <PageHeader
        title="Appointments"
        subtitle={`${appointments.length} appointments`}
        action={
          <Button variant="contained" startIcon={<Add />} onClick={() => navigate('/appointments/book')}>
            Book Appointment
          </Button>
        }
      />

      <Card>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap' }}>
            <TextField
              select size="small" value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              sx={{ minWidth: 200 }} label="Status"
            >
              {STATUS_OPTIONS.map(s => <MenuItem key={s} value={s}>{s.replace(/_/g, ' ')}</MenuItem>)}
            </TextField>
          </Box>

          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  {['#', 'Date', 'Time', 'Status', 'Payment', 'Fee', 'Actions'].map(h => (
                    <TableCell key={h} sx={{ fontWeight: 600, color: 'text.secondary', fontSize: '0.8rem', whiteSpace: 'nowrap' }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {loading
                  ? Array.from({ length: 5 }).map((_, i) => (
                      <TableRow key={i}>{Array.from({ length: 7 }).map((_, j) => (
                        <TableCell key={j}><Box sx={{ height: 20, bgcolor: 'action.hover', borderRadius: 1 }} /></TableCell>
                      ))}</TableRow>
                    ))
                  : paged.length === 0
                  ? <TableRow><TableCell colSpan={7}><EmptyState icon={<CalendarMonth />} title="No appointments found" /></TableCell></TableRow>
                  : paged.map((a, idx) => (
                    <TableRow key={a.appointmentId} hover>
                      <TableCell sx={{ color: 'text.secondary', fontSize: '0.8rem' }}>{page * rowsPerPage + idx + 1}</TableCell>
                      <TableCell sx={{ fontWeight: 500 }}>{a.appointmentDate}</TableCell>
                      <TableCell>{a.appointmentTime}</TableCell>
                      <TableCell><StatusChip status={a.status} /></TableCell>
                      <TableCell><StatusChip status={a.paymentStatus} /></TableCell>
                      <TableCell>₹{a.consultationFee}</TableCell>
                      <TableCell>
                        <Tooltip title="View">
                          <IconButton size="small" color="info" onClick={() => navigate(`/appointments/${a.appointmentId}`)}>
                            <Visibility fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </TableContainer>

          <TablePagination
            component="div" count={filtered.length} page={page}
            onPageChange={(_, p) => setPage(p)} rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(+e.target.value); setPage(0) }}
            rowsPerPageOptions={[5, 10, 25]}
          />
        </CardContent>
      </Card>
    </Box>
  )
}

export default AppointmentList
