import React, { useState, useEffect } from 'react'
import { Card, CardContent, Typography, Grid, TextField, Button, Box, MenuItem } from '@mui/material'
import { CalendarMonth, Save, Cancel } from '@mui/icons-material'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { PageHeader } from '../../components/Loader'
import { showSnackbar } from '../../redux/slices/uiSlice'
import appointmentService from '../../services/appointmentService'
import doctorService from '../../services/doctorService'

const schema = yup.object({
  patientProfileId: yup.number().typeError('Patient profile ID required').required('Required'),
  doctorId:         yup.number().typeError('Select a doctor').required('Required'),
  departmentId:     yup.number().typeError('Select a department').required('Required'),
  appointmentDate:  yup.string().required('Date is required'),
  appointmentTime:  yup.string().required('Time is required'),
  reason:           yup.string().required('Reason is required'),
})

function BookAppointment() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [loading, setLoading] = useState(false)
  const [departments, setDepartments] = useState([])
  const [doctors, setDoctors] = useState([])

  const { register, handleSubmit, watch, formState: { errors } } = useForm({ resolver: yupResolver(schema) })
  const selectedDept = watch('departmentId')

  // Load departments on mount
  useEffect(() => {
    doctorService.getAllDepartments()
      .then(d => setDepartments(Array.isArray(d) ? d : []))
      .catch(() => {})
  }, [])

  // Load doctors when department changes
  useEffect(() => {
    if (selectedDept) {
      doctorService.getByDepartment(selectedDept)
        .then(d => setDoctors(Array.isArray(d) ? d : []))
        .catch(() => setDoctors([]))
    }
  }, [selectedDept])

  const onSubmit = async (data) => {
    setLoading(true)
    try {
      // POST /appointments
      // Request: BookAppointmentRequest {
      //   patientProfileId, doctorId, departmentId,
      //   appointmentDate (LocalDate), appointmentTime (LocalTime), reason
      // }
      const payload = {
        patientProfileId: Number(data.patientProfileId),
        doctorId:         Number(data.doctorId),
        departmentId:     Number(data.departmentId),
        appointmentDate:  data.appointmentDate,        // YYYY-MM-DD
        appointmentTime:  data.appointmentTime + ':00', // HH:mm → HH:mm:ss
        reason:           data.reason,
      }
      await appointmentService.book(payload)
      dispatch(showSnackbar({ message: 'Appointment booked successfully!', severity: 'success' }))
      navigate('/appointments')
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to book appointment'
      dispatch(showSnackbar({ message: msg, severity: 'error' }))
    } finally {
      setLoading(false)
    }
  }

  return (
    <Box>
      <PageHeader title="Book Appointment" subtitle="Schedule a new patient appointment" />

      <Card sx={{ maxWidth: 700 }}>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 3 }}>
            <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#FFF7ED', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <CalendarMonth sx={{ color: 'primary.main' }} />
            </Box>
            <Typography variant="h6" fontWeight={600}>Appointment Details</Typography>
          </Box>

          <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate>
            <Grid container spacing={2.5}>
              <Grid item xs={12}>
                <TextField
                  label="Patient Profile ID" type="number" fullWidth
                  {...register('patientProfileId')}
                  error={!!errors.patientProfileId} helperText={errors.patientProfileId?.message}
                  placeholder="Enter the patient's profile ID"
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select label="Department" fullWidth defaultValue=""
                  {...register('departmentId')} error={!!errors.departmentId} helperText={errors.departmentId?.message}
                >
                  {departments.map(d => (
                    <MenuItem key={d.departmentId} value={d.departmentId}>{d.departmentName}</MenuItem>
                  ))}
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  select label="Doctor" fullWidth defaultValue=""
                  {...register('doctorId')} error={!!errors.doctorId} helperText={errors.doctorId?.message}
                  disabled={!selectedDept || doctors.length === 0}
                >
                  {doctors.map(d => (
                    <MenuItem key={d.doctorId} value={d.doctorId}>
                      {d.doctorName} — ₹{d.consultationFee}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Appointment Date" type="date" fullWidth
                  {...register('appointmentDate')} error={!!errors.appointmentDate} helperText={errors.appointmentDate?.message}
                  InputLabelProps={{ shrink: true }}
                  inputProps={{ min: new Date().toISOString().split('T')[0] }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  label="Appointment Time" type="time" fullWidth
                  {...register('appointmentTime')} error={!!errors.appointmentTime} helperText={errors.appointmentTime?.message}
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  label="Reason for Visit" fullWidth multiline rows={3}
                  {...register('reason')} error={!!errors.reason} helperText={errors.reason?.message}
                  placeholder="Describe the reason for the appointment"
                />
              </Grid>
            </Grid>

            <Box sx={{ display: 'flex', gap: 2, mt: 3 }}>
              <Button type="submit" variant="contained" startIcon={<Save />} disabled={loading}>
                {loading ? 'Booking…' : 'Book Appointment'}
              </Button>
              <Button variant="outlined" startIcon={<Cancel />} onClick={() => navigate('/appointments')}>Cancel</Button>
            </Box>
          </Box>
        </CardContent>
      </Card>
    </Box>
  )
}

export default BookAppointment
