import React, { useEffect, useState } from 'react'
import {
  Grid, Card, CardContent, Typography, Box, Button, Divider,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField
} from '@mui/material'
import { ArrowBack, Cancel, Replay, TaskAlt, CalendarMonth } from '@mui/icons-material'
import { useParams, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { PageHeader, Loader } from '../../components/Loader'
import StatusChip from '../../components/StatusChip'
import { showSnackbar } from '../../redux/slices/uiSlice'
import appointmentService from '../../services/appointmentService'

function InfoRow({ label, value }) {
  return (
    <Box sx={{ display: 'flex', py: 1.2, borderBottom: '1px solid', borderColor: 'divider' }}>
      <Typography variant="body2" color="text.secondary" sx={{ width: 180, flexShrink: 0 }}>{label}</Typography>
      <Typography variant="body2" fontWeight={500}>{value || '—'}</Typography>
    </Box>
  )
}

function AppointmentDetails() {
  const { id } = useParams()
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { user } = useSelector(s => s.auth)
  const [appt, setAppt] = useState(null)
  const [history, setHistory] = useState([])
  const [loading, setLoading] = useState(true)
  const [dialog, setDialog] = useState(null) // 'cancel' | 'reschedule' | 'confirm'
  const [form, setForm] = useState({ reason: '', newDate: '', newTime: '' })

  const load = async () => {
    try {
      const [a, h] = await Promise.all([
        appointmentService.getById(id),
        appointmentService.getHistory(id).catch(() => []),
      ])
      setAppt(a)
      setHistory(Array.isArray(h) ? h : [])
    } catch {
      dispatch(showSnackbar({ message: 'Appointment not found', severity: 'error' }))
      navigate('/appointments')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [id])

  const handleConfirm = async () => {
    try {
      // PUT /appointments/{id}/confirm
      // Request: { confirmedBy, email }
      await appointmentService.confirm(id, {
        confirmedBy: user?.name || 'Admin',
        email: user?.email || '',
      })
      dispatch(showSnackbar({ message: 'Appointment confirmed', severity: 'success' }))
      setDialog(null)
      load()
    } catch (err) {
      dispatch(showSnackbar({ message: err.response?.data?.message || 'Action failed', severity: 'error' }))
    }
  }

  const handleCancel = async () => {
    if (!form.reason) {
      dispatch(showSnackbar({ message: 'Cancellation reason is required', severity: 'warning' }))
      return
    }
    try {
      // PUT /appointments/{id}/cancel
      // Request: { reason, cancelledBy, email }
      await appointmentService.cancel(id, {
        reason: form.reason,
        cancelledBy: user?.name || 'Admin',
        email: user?.email || '',
      })
      dispatch(showSnackbar({ message: 'Appointment cancelled', severity: 'success' }))
      setDialog(null)
      load()
    } catch (err) {
      dispatch(showSnackbar({ message: err.response?.data?.message || 'Action failed', severity: 'error' }))
    }
  }

  const handleReschedule = async () => {
    if (!form.newDate || !form.newTime) {
      dispatch(showSnackbar({ message: 'New date and time are required', severity: 'warning' }))
      return
    }
    try {
      // PUT /appointments/{id}/reschedule
      // Request: { newDate, newTime, remarks, requestedBy, email }
      await appointmentService.reschedule(id, {
        newDate: form.newDate,
        newTime: form.newTime + ':00',
        remarks: form.reason,
        requestedBy: user?.name || 'Admin',
        email: user?.email || '',
      })
      dispatch(showSnackbar({ message: 'Appointment rescheduled', severity: 'success' }))
      setDialog(null)
      load()
    } catch (err) {
      dispatch(showSnackbar({ message: err.response?.data?.message || 'Action failed', severity: 'error' }))
    }
  }

  const handleComplete = async () => {
    try {
      // PUT /appointments/{id}/complete  (no body)
      await appointmentService.complete(id)
      dispatch(showSnackbar({ message: 'Appointment marked complete', severity: 'success' }))
      load()
    } catch (err) {
      dispatch(showSnackbar({ message: err.response?.data?.message || 'Action failed', severity: 'error' }))
    }
  }

  if (loading) return <Loader />
  if (!appt) return null

  const canConfirm     = appt.status === 'PENDING'
  const canCancel      = ['PENDING', 'CONFIRMED', 'WAITING_FOR_DOCTOR'].includes(appt.status)
  const canReschedule  = ['PENDING', 'CONFIRMED'].includes(appt.status)
  const canComplete    = appt.status === 'CONFIRMED'

  return (
    <Box>
      <PageHeader
        title="Appointment Details"
        action={<Button variant="outlined" startIcon={<ArrowBack />} onClick={() => navigate('/appointments')}>Back</Button>}
      />

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Card sx={{ mb: 3 }}>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2 }}>
                <Box sx={{ width: 36, height: 36, borderRadius: 2, bgcolor: '#FFF7ED', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <CalendarMonth sx={{ color: '#F97316', fontSize: 20 }} />
                </Box>
                <Typography variant="h6" fontWeight={600}>Appointment Info</Typography>
              </Box>
              <InfoRow label="Appointment ID" value={`#${appt.appointmentId}`} />
              <InfoRow label="Patient Profile ID" value={appt.patientProfileId} />
              <InfoRow label="Doctor ID" value={appt.doctorId} />
              <InfoRow label="Department ID" value={appt.departmentId} />
              <InfoRow label="Date" value={appt.appointmentDate} />
              <InfoRow label="Time" value={appt.appointmentTime} />
              <InfoRow label="Consultation Fee" value={`₹${appt.consultationFee}`} />
              <InfoRow label="Message" value={appt.message} />
            </CardContent>
          </Card>

          {/* History */}
          {history.length > 0 && (
            <Card>
              <CardContent sx={{ p: 3 }}>
                <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>Appointment History</Typography>
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        {['Action', 'From', 'To', 'By', 'Remarks', 'Date'].map(h => (
                          <TableCell key={h} sx={{ fontWeight: 600, color: 'text.secondary', fontSize: '0.75rem' }}>{h}</TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {history.map(h => (
                        <TableRow key={h.id}>
                          <TableCell sx={{ fontSize: '0.8rem', fontWeight: 600 }}>{h.action}</TableCell>
                          <TableCell><StatusChip status={h.oldStatus} /></TableCell>
                          <TableCell><StatusChip status={h.newStatus} /></TableCell>
                          <TableCell sx={{ fontSize: '0.8rem' }}>{h.changedBy}</TableCell>
                          <TableCell sx={{ fontSize: '0.8rem' }}>{h.remarks}</TableCell>
                          <TableCell sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>
                            {h.changedAt ? new Date(h.changedAt).toLocaleDateString() : ''}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </CardContent>
            </Card>
          )}
        </Grid>

        {/* Actions sidebar */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>Status</Typography>
              <StatusChip status={appt.status} />
              <Box sx={{ mt: 1 }}><StatusChip status={appt.paymentStatus} /></Box>
              <Divider sx={{ my: 3 }} />
              <Typography variant="subtitle2" fontWeight={600} sx={{ mb: 2 }}>Actions</Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                {canConfirm && (
                  <Button variant="contained" color="success" startIcon={<TaskAlt />} fullWidth onClick={handleConfirm}>
                    Confirm Appointment
                  </Button>
                )}
                {canReschedule && (
                  <Button variant="outlined" color="warning" startIcon={<Replay />} fullWidth onClick={() => { setForm({ reason: '', newDate: '', newTime: '' }); setDialog('reschedule') }}>
                    Reschedule
                  </Button>
                )}
                {canComplete && (
                  <Button variant="contained" color="primary" startIcon={<TaskAlt />} fullWidth onClick={handleComplete}>
                    Mark Complete
                  </Button>
                )}
                {canCancel && (
                  <Button variant="outlined" color="error" startIcon={<Cancel />} fullWidth onClick={() => { setForm({ reason: '', newDate: '', newTime: '' }); setDialog('cancel') }}>
                    Cancel Appointment
                  </Button>
                )}
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Cancel Dialog */}
      <Dialog open={dialog === 'cancel'} onClose={() => setDialog(null)} maxWidth="xs" fullWidth>
        <DialogTitle fontWeight={600}>Cancel Appointment</DialogTitle>
        <DialogContent sx={{ pt: '16px !important' }}>
          <TextField
            label="Cancellation Reason" fullWidth multiline rows={3}
            value={form.reason} onChange={e => setForm(p => ({ ...p, reason: e.target.value }))}
            placeholder="Please provide a reason for cancellation"
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDialog(null)} variant="outlined">Back</Button>
          <Button onClick={handleCancel} variant="contained" color="error">Confirm Cancel</Button>
        </DialogActions>
      </Dialog>

      {/* Reschedule Dialog */}
      <Dialog open={dialog === 'reschedule'} onClose={() => setDialog(null)} maxWidth="xs" fullWidth>
        <DialogTitle fontWeight={600}>Reschedule Appointment</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2.5, pt: '16px !important' }}>
          <TextField
            label="New Date" type="date" fullWidth
            value={form.newDate} onChange={e => setForm(p => ({ ...p, newDate: e.target.value }))}
            InputLabelProps={{ shrink: true }}
            inputProps={{ min: new Date().toISOString().split('T')[0] }}
          />
          <TextField
            label="New Time" type="time" fullWidth
            value={form.newTime} onChange={e => setForm(p => ({ ...p, newTime: e.target.value }))}
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            label="Remarks (optional)" fullWidth
            value={form.reason} onChange={e => setForm(p => ({ ...p, reason: e.target.value }))}
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDialog(null)} variant="outlined">Cancel</Button>
          <Button onClick={handleReschedule} variant="contained">Reschedule</Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default AppointmentDetails
