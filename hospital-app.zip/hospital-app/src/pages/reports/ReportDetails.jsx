import React, { useEffect, useState } from 'react'
import {
  Grid, Card, CardContent, Typography, Box, Button, Divider,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField
} from '@mui/material'
import { ArrowBack, Download, Add, Delete } from '@mui/icons-material'
import { useParams, useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { PageHeader, Loader } from '../../components/Loader'
import StatusChip from '../../components/StatusChip'
import { showSnackbar } from '../../redux/slices/uiSlice'
import { reportService } from '../../services/otherServices'

function InfoRow({ label, value }) {
  return (
    <Box sx={{ display: 'flex', py: 1.2, borderBottom: '1px solid', borderColor: 'divider' }}>
      <Typography variant="body2" color="text.secondary" sx={{ width: 160, flexShrink: 0 }}>{label}</Typography>
      <Typography variant="body2" fontWeight={500}>{value || '—'}</Typography>
    </Box>
  )
}

const emptyRx = { medicineName: '', dosage: '', frequency: '', duration: '', instructions: '' }

function ReportDetails() {
  const { id } = useParams() // reportId
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [report, setReport] = useState(null)
  const [prescriptions, setPrescriptions] = useState([])
  const [loading, setLoading] = useState(true)
  const [rxDialog, setRxDialog] = useState(false)
  const [rxForm, setRxForm] = useState(emptyRx)
  const [saving, setSaving] = useState(false)

  const load = async () => {
    try {
      const [r, rxList] = await Promise.all([
        reportService.getById(id),
        reportService.getPrescriptions(id).catch(() => []),
      ])
      setReport(r)
      setPrescriptions(Array.isArray(rxList) ? rxList : [])
    } catch {
      dispatch(showSnackbar({ message: 'Report not found', severity: 'error' }))
      navigate('/reports')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [id])

  const handleDownloadPdf = async () => {
    try {
      // GET /reports/{reportId}/pdf
      const blob = await reportService.downloadPdf(id)
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `report-${id}.pdf`
      a.click()
      window.URL.revokeObjectURL(url)
    } catch {
      dispatch(showSnackbar({ message: 'Failed to download PDF', severity: 'error' }))
    }
  }

  const handleAddPrescription = async () => {
    if (!rxForm.medicineName || !rxForm.dosage) {
      dispatch(showSnackbar({ message: 'Medicine name and dosage are required', severity: 'warning' }))
      return
    }
    setSaving(true)
    try {
      // POST /reports/{reportId}/prescriptions
      await reportService.addPrescription(id, rxForm)
      dispatch(showSnackbar({ message: 'Prescription added', severity: 'success' }))
      setRxDialog(false)
      setRxForm(emptyRx)
      load()
    } catch {
      dispatch(showSnackbar({ message: 'Failed to add prescription', severity: 'error' }))
    } finally {
      setSaving(false)
    }
  }

  const handleDeletePrescription = async (prescriptionId) => {
    try {
      // DELETE /prescriptions/{prescriptionId}
      await reportService.deletePrescription(prescriptionId)
      dispatch(showSnackbar({ message: 'Prescription removed', severity: 'success' }))
      load()
    } catch {
      dispatch(showSnackbar({ message: 'Failed to remove prescription', severity: 'error' }))
    }
  }

  if (loading) return <Loader />
  if (!report) return null

  return (
    <Box>
      <PageHeader
        title="Report Details"
        action={
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Button variant="outlined" startIcon={<ArrowBack />} onClick={() => navigate('/reports')}>Back</Button>
            <Button variant="contained" startIcon={<Download />} onClick={handleDownloadPdf}>Download PDF</Button>
          </Box>
        }
      />

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          {/* Diagnosis & Remarks */}
          <Card sx={{ mb: 3 }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>Medical Details</Typography>
              <InfoRow label="Diagnosis" value={report.diagnosis} />
              <InfoRow label="Remarks" value={report.remarks} />
              <InfoRow label="Next Visit Date" value={report.nextVisitDate} />
            </CardContent>
          </Card>

          {/* Prescriptions */}
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6" fontWeight={600}>Prescriptions</Typography>
                <Button size="small" startIcon={<Add />} onClick={() => setRxDialog(true)}>Add</Button>
              </Box>
              {prescriptions.length === 0 ? (
                <Typography variant="body2" color="text.secondary">No prescriptions added.</Typography>
              ) : (
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        {['Medicine', 'Dosage', 'Frequency', 'Duration', 'Instructions', ''].map(h => (
                          <TableCell key={h} sx={{ fontWeight: 600, color: 'text.secondary', fontSize: '0.75rem' }}>{h}</TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {prescriptions.map(rx => (
                        <TableRow key={rx.prescriptionId}>
                          <TableCell sx={{ fontWeight: 500 }}>{rx.medicineName}</TableCell>
                          <TableCell>{rx.dosage}</TableCell>
                          <TableCell>{rx.frequency}</TableCell>
                          <TableCell>{rx.duration}</TableCell>
                          <TableCell>{rx.instructions}</TableCell>
                          <TableCell>
                            <Button size="small" color="error" onClick={() => handleDeletePrescription(rx.prescriptionId)}>
                              <Delete fontSize="small" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Sidebar */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>Report Info</Typography>
              <InfoRow label="Report ID" value={`#${report.reportId}`} />
              <InfoRow label="Appointment" value={`#${report.appointmentId}`} />
              <InfoRow label="Patient Profile" value={`#${report.patientProfileId}`} />
              <InfoRow label="Doctor" value={`#${report.doctorId}`} />
              <InfoRow label="Version" value={report.version} />
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', pt: 1.5 }}>
                <Typography variant="body2" color="text.secondary">Status</Typography>
                {/* ReportStatus: DRAFT | COMPLETED | UPDATED */}
                <StatusChip status={report.status} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Add Prescription Dialog */}
      <Dialog open={rxDialog} onClose={() => setRxDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle fontWeight={600}>Add Prescription</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2.5, pt: '16px !important' }}>
          {[
            { label: 'Medicine Name', key: 'medicineName', placeholder: 'e.g. Paracetamol' },
            { label: 'Dosage', key: 'dosage', placeholder: 'e.g. 500mg' },
            { label: 'Frequency', key: 'frequency', placeholder: 'e.g. Twice Daily' },
            { label: 'Duration', key: 'duration', placeholder: 'e.g. 5 Days' },
            { label: 'Instructions', key: 'instructions', placeholder: 'e.g. After Food' },
          ].map(({ label, key, placeholder }) => (
            <TextField
              key={key} label={label} fullWidth placeholder={placeholder}
              value={rxForm[key]}
              onChange={e => setRxForm(p => ({ ...p, [key]: e.target.value }))}
            />
          ))}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setRxDialog(false)} variant="outlined">Cancel</Button>
          <Button onClick={handleAddPrescription} variant="contained" disabled={saving}>
            {saving ? 'Adding…' : 'Add Prescription'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

export default ReportDetails
