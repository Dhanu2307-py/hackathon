import React, { useEffect, useState } from 'react'
import {
  Card, CardContent, Box, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, TablePagination,
  IconButton, Tooltip, TextField
} from '@mui/material'
import { Visibility, Assessment } from '@mui/icons-material'
import { useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { PageHeader, EmptyState } from '../../components/Loader'
import StatusChip from '../../components/StatusChip'
import { showSnackbar } from '../../redux/slices/uiSlice'
import { reportService } from '../../services/otherServices'

function ReportsList() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { user, role } = useSelector(s => s.auth)
  const [reports, setReports] = useState([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(10)
  // For admin: allow searching by patient profile ID or doctor ID
  const [searchId, setSearchId] = useState('')
  const [searchType, setSearchType] = useState('patient')

  const fetchReports = async () => {
    setLoading(true)
    try {
      let data = []
      if (role === 'PATIENT' && user?.patientProfileId) {
        // GET /reports/patient/{profileId}
        data = await reportService.getByPatient(user.patientProfileId)
      } else if (role === 'DOCTOR' && user?.doctorId) {
        // GET /reports/doctor/{doctorId}
        data = await reportService.getByDoctor(user.doctorId)
      } else if (searchId) {
        // Admin: search by ID
        if (searchType === 'patient') data = await reportService.getByPatient(searchId)
        else data = await reportService.getByDoctor(searchId)
      }
      setReports(Array.isArray(data) ? data : [])
    } catch {
      dispatch(showSnackbar({ message: 'Failed to load reports', severity: 'error' }))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchReports() }, [])

  const paged = reports.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)

  return (
    <Box>
      <PageHeader title="Reports" subtitle={`${reports.length} medical reports`} />

      {role === 'ADMIN' && (
        <Card sx={{ mb: 3 }}>
          <CardContent sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', gap: 2 }}>
              <select
                value={searchType}
                onChange={e => setSearchType(e.target.value)}
                style={{ padding: '10px', borderRadius: 8, border: '1px solid #E2E8F0', fontSize: '0.875rem' }}
              >
                <option value="patient">By Patient Profile ID</option>
                <option value="doctor">By Doctor ID</option>
              </select>
              <Box component="input"
                value={searchId}
                onChange={e => setSearchId(e.target.value)}
                placeholder="Enter ID…"
                onKeyDown={e => e.key === 'Enter' && fetchReports()}
                style={{ flex: 1, padding: '10px 14px', borderRadius: 10, border: '1px solid #E2E8F0', fontSize: '0.875rem', fontFamily: 'Roboto, sans-serif' }}
              />
              <button
                onClick={fetchReports}
                style={{ padding: '10px 20px', borderRadius: 10, background: '#F97316', color: 'white', border: 'none', cursor: 'pointer', fontWeight: 600 }}
              >
                Search
              </button>
            </Box>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent sx={{ p: 3 }}>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  {['Report ID', 'Appointment', 'Patient', 'Doctor', 'Diagnosis', 'Next Visit', 'Status', 'Actions'].map(h => (
                    <TableCell key={h} sx={{ fontWeight: 600, color: 'text.secondary', fontSize: '0.8rem', whiteSpace: 'nowrap' }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {loading
                  ? Array.from({ length: 3 }).map((_, i) => (
                      <TableRow key={i}>{Array.from({ length: 8 }).map((_, j) => (
                        <TableCell key={j}><Box sx={{ height: 20, bgcolor: 'action.hover', borderRadius: 1 }} /></TableCell>
                      ))}</TableRow>
                    ))
                  : paged.length === 0
                  ? <TableRow><TableCell colSpan={8}><EmptyState icon={<Assessment />} title="No reports found" subtitle="Reports are generated after completed appointments." /></TableCell></TableRow>
                  : paged.map(r => (
                    <TableRow key={r.reportId} hover>
                      <TableCell sx={{ fontFamily: 'monospace', fontWeight: 600 }}>#{r.reportId}</TableCell>
                      <TableCell>#{r.appointmentId}</TableCell>
                      <TableCell>#{r.patientProfileId}</TableCell>
                      <TableCell>#{r.doctorId}</TableCell>
                      <TableCell sx={{ maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.diagnosis}</TableCell>
                      <TableCell>{r.nextVisitDate}</TableCell>
                      <TableCell>
                        {/* ReportStatus: DRAFT | COMPLETED | UPDATED */}
                        <StatusChip status={r.status} />
                      </TableCell>
                      <TableCell>
                        <Tooltip title="View Report">
                          <IconButton size="small" color="info" onClick={() => navigate(`/reports/${r.reportId}`)}>
                            <Visibility fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            component="div" count={reports.length} page={page}
            onPageChange={(_, p) => setPage(p)} rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(+e.target.value); setPage(0) }}
            rowsPerPageOptions={[5, 10, 25]}
          />
        </CardContent>
      </Card>
    </Box>
  )
}

export default ReportsList
