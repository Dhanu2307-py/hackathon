import React, { useState } from 'react'
import {
  Card, CardContent, Typography, Box, Button, TextField, MenuItem,
  Divider, Grid, Alert
} from '@mui/material'
import { Payment, CreditCard, CheckCircle } from '@mui/icons-material'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { PageHeader } from '../../components/Loader'
import { showSnackbar } from '../../redux/slices/uiSlice'
import { paymentService } from '../../services/otherServices'

const schema = yup.object({
  appointmentId: yup.number().typeError('Appointment ID required').required('Required'),
  patientId:     yup.number().typeError('Patient ID required').required('Required'),
  doctorId:      yup.number().typeError('Doctor ID required').required('Required'),
  amount:        yup.number().typeError('Amount required').min(1).required('Required'),
})

const PAYMENT_METHODS = ['Credit Card', 'Debit Card', 'UPI', 'Net Banking', 'Cash']

function PaymentPage() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [loading, setLoading] = useState(false)
  const [paid, setPaid] = useState(false)
  const [paymentResult, setPaymentResult] = useState(null)
  const [method, setMethod] = useState('')

  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: yupResolver(schema) })

  const onSubmit = async (data) => {
    setLoading(true)
    try {
      // POST /payments
      // Request: { appointmentId, patientId, doctorId, amount }
      // Response: { paymentId, appointmentId, patientId, amount, status }
      const result = await paymentService.create({
        appointmentId: Number(data.appointmentId),
        patientId:     Number(data.patientId),
        doctorId:      Number(data.doctorId),
        amount:        Number(data.amount),
      })
      setPaymentResult(result)
      setPaid(true)
      dispatch(showSnackbar({ message: 'Payment successful!', severity: 'success' }))
    } catch (err) {
      const msg = err.response?.data?.message || 'Payment failed. Please try again.'
      dispatch(showSnackbar({ message: msg, severity: 'error' }))
    } finally {
      setLoading(false)
    }
  }

  if (paid && paymentResult) {
    return (
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
        <Card sx={{ maxWidth: 440, width: '100%', textAlign: 'center' }}>
          <CardContent sx={{ p: 5 }}>
            <CheckCircle sx={{ fontSize: 72, color: 'success.main', mb: 2 }} />
            <Typography variant="h5" fontWeight={700} gutterBottom>Payment Successful!</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              Payment ID: <strong>#{paymentResult.paymentId}</strong>
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              Amount: <strong>₹{paymentResult.amount}</strong> — Status: <strong>{paymentResult.status}</strong>
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center' }}>
              <Button variant="contained" onClick={() => navigate('/payments/history')}>View History</Button>
              <Button variant="outlined" onClick={() => navigate('/appointments')}>Appointments</Button>
            </Box>
          </CardContent>
        </Card>
      </Box>
    )
  }

  return (
    <Box>
      <PageHeader title="Make Payment" subtitle="Process appointment payment" />

      <Card sx={{ maxWidth: 560 }}>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 3 }}>
            <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#FFF7ED', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Payment sx={{ color: 'primary.main' }} />
            </Box>
            <Typography variant="h6" fontWeight={600}>Payment Details</Typography>
          </Box>

          <Alert severity="info" sx={{ mb: 3, borderRadius: 2 }}>
            Enter the appointment, patient and doctor IDs from the appointment details page.
          </Alert>

          <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
            <TextField
              label="Appointment ID" type="number" fullWidth
              {...register('appointmentId')} error={!!errors.appointmentId} helperText={errors.appointmentId?.message}
            />
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <TextField
                  label="Patient ID" type="number" fullWidth
                  {...register('patientId')} error={!!errors.patientId} helperText={errors.patientId?.message}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Doctor ID" type="number" fullWidth
                  {...register('doctorId')} error={!!errors.doctorId} helperText={errors.doctorId?.message}
                />
              </Grid>
            </Grid>
            <TextField
              label="Amount (₹)" type="number" fullWidth
              {...register('amount')} error={!!errors.amount} helperText={errors.amount?.message}
              inputProps={{ min: 1 }}
            />
            <TextField
              select label="Payment Method" value={method}
              onChange={e => setMethod(e.target.value)} fullWidth
            >
              {PAYMENT_METHODS.map(m => <MenuItem key={m} value={m}>{m}</MenuItem>)}
            </TextField>

            <Button
              type="submit" variant="contained" fullWidth size="large"
              startIcon={<CreditCard />} disabled={loading} sx={{ mt: 1 }}
            >
              {loading ? 'Processing…' : 'Pay Now'}
            </Button>
          </Box>
        </CardContent>
      </Card>
    </Box>
  )
}

export default PaymentPage
