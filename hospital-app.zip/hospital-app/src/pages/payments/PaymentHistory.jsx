import React, { useEffect, useState } from 'react'
import {
  Card, CardContent, Box, Typography, Button,
  Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TablePagination
} from '@mui/material'
import { Payment, Replay } from '@mui/icons-material'
import { useDispatch } from 'react-redux'
import { PageHeader, EmptyState, ConfirmDialog } from '../../components/Loader'
import StatusChip from '../../components/StatusChip'
import { showSnackbar } from '../../redux/slices/uiSlice'
import { paymentService } from '../../services/otherServices'

function PaymentHistory() {
  const dispatch = useDispatch()
  const [payments, setPayments] = useState([])
  const [loading, setLoading] = useState(false)
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(10)
  const [refundId, setRefundId] = useState(null)
  const [searchId, setSearchId] = useState('')
  const [searched, setSearched] = useState(false)

  const fetchById = async () => {
    if (!searchId) return
    setLoading(true)
    try {
      // GET /payments/{id}
      const data = await paymentService.getById(searchId)
      setPayments(data ? [data] : [])
      setSearched(true)
    } catch {
      dispatch(showSnackbar({ message: 'Payment not found', severity: 'error' }))
      setPayments([])
    } finally {
      setLoading(false)
    }
  }

  const handleRefund = async () => {
    try {
      // POST /payments/refund/{id}
      await paymentService.refund(refundId)
      dispatch(showSnackbar({ message: 'Refund processed successfully', severity: 'success' }))
      setRefundId(null)
      fetchById()
    } catch {
      dispatch(showSnackbar({ message: 'Refund failed', severity: 'error' }))
    }
  }

  const paged = payments.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)

  return (
    <Box>
      <PageHeader title="Payment History" subtitle="Look up payments by ID" />

      <Card sx={{ mb: 3 }}>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
            <Box
              component="input"
              value={searchId}
              onChange={e => setSearchId(e.target.value)}
              placeholder="Enter Payment ID…"
              onKeyDown={e => e.key === 'Enter' && fetchById()}
              style={{
                flex: 1, padding: '10px 14px', borderRadius: 10,
                border: '1px solid #E2E8F0', fontSize: '0.875rem',
                outline: 'none', fontFamily: 'Roboto, sans-serif',
              }}
            />
            <Button variant="contained" onClick={fetchById} disabled={loading}>
              {loading ? 'Searching…' : 'Search'}
            </Button>
          </Box>
        </CardContent>
      </Card>

      <Card>
        <CardContent sx={{ p: 3 }}>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  {['Payment ID', 'Appointment ID', 'Patient ID', 'Amount', 'Status', 'Actions'].map(h => (
                    <TableCell key={h} sx={{ fontWeight: 600, color: 'text.secondary', fontSize: '0.8rem' }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {paged.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6}>
                      <EmptyState
                        icon={<Payment />}
                        title={searched ? 'No payment found' : 'Search for a payment'}
                        subtitle={searched ? 'Try a different ID' : 'Enter a payment ID above to look it up'}
                      />
                    </TableCell>
                  </TableRow>
                ) : paged.map(p => (
                  <TableRow key={p.paymentId} hover>
                    <TableCell sx={{ fontFamily: 'monospace', fontWeight: 600 }}>#{p.paymentId}</TableCell>
                    <TableCell>#{p.appointmentId}</TableCell>
                    <TableCell>#{p.patientId}</TableCell>
                    <TableCell sx={{ fontWeight: 600, color: 'success.main' }}>₹{p.amount}</TableCell>
                    <TableCell>
                      {/* PaymentStatus: SUCCESS | FAILED | REFUNDED */}
                      <StatusChip status={p.status} />
                    </TableCell>
                    <TableCell>
                      {p.status === 'SUCCESS' && (
                        <Button size="small" color="warning" startIcon={<Replay />} onClick={() => setRefundId(p.paymentId)}>
                          Refund
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          {payments.length > rowsPerPage && (
            <TablePagination
              component="div" count={payments.length} page={page}
              onPageChange={(_, p) => setPage(p)} rowsPerPage={rowsPerPage}
              onRowsPerPageChange={e => { setRowsPerPage(+e.target.value); setPage(0) }}
              rowsPerPageOptions={[5, 10, 25]}
            />
          )}
        </CardContent>
      </Card>

      <ConfirmDialog
        open={!!refundId}
        onClose={() => setRefundId(null)}
        onConfirm={handleRefund}
        title="Process Refund"
        message="Are you sure you want to process a refund for this payment? This action cannot be undone."
        confirmLabel="Process Refund"
        confirmColor="warning"
      />
    </Box>
  )
}

export default PaymentHistory
