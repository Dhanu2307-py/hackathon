import React, { useEffect, useState } from 'react'
import { Card, CardContent, Typography, Grid, TextField, Button, Box, MenuItem } from '@mui/material'
import { Save, Cancel } from '@mui/icons-material'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useNavigate, useParams } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { PageHeader, Loader } from '../../components/Loader'
import { showSnackbar } from '../../redux/slices/uiSlice'
import patientService from '../../services/patientService'

// Gender enum: MALE | FEMALE | OTHER
const GENDERS = ['MALE', 'FEMALE', 'OTHER']

// BloodGroup enum: A_POSITIVE | A_NEGATIVE | B_POSITIVE | B_NEGATIVE |
//                  AB_POSITIVE | AB_NEGATIVE | O_POSITIVE | O_NEGATIVE
const BLOOD_GROUPS = ['A_POSITIVE','A_NEGATIVE','B_POSITIVE','B_NEGATIVE','AB_POSITIVE','AB_NEGATIVE','O_POSITIVE','O_NEGATIVE']
const BLOOD_LABELS = { A_POSITIVE:'A+', A_NEGATIVE:'A-', B_POSITIVE:'B+', B_NEGATIVE:'B-', AB_POSITIVE:'AB+', AB_NEGATIVE:'AB-', O_POSITIVE:'O+', O_NEGATIVE:'O-' }

const schema = yup.object({
  firstName:   yup.string().min(2).max(50).required('First name is required'),
  lastName:    yup.string().min(2).max(50).required('Last name is required'),
  gender:      yup.string().required('Gender is required'),
  dateOfBirth: yup.string().required('Date of birth is required'),
  bloodGroup:  yup.string().required('Blood group is required'),
  phoneNumber: yup.string().matches(/^[6-9]\d{9}$/, 'Enter valid 10-digit mobile number').required('Phone is required'),
  email:       yup.string().email('Invalid email').required('Email is required'),
  address:     yup.string().required('Address is required'),
  city:        yup.string().required('City is required'),
  state:       yup.string().required('State is required'),
  pincode:     yup.string().matches(/^\d{6}$/, 'Pincode must be 6 digits').required('Pincode is required'),
})

function PatientForm() {
  const { id } = useParams()
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { user } = useSelector(s => s.auth)
  const isEdit = !!id
  const [loading, setLoading] = useState(isEdit)
  const [saving, setSaving] = useState(false)

  const { register, handleSubmit, reset, formState: { errors } } = useForm({ resolver: yupResolver(schema) })

  useEffect(() => {
    if (isEdit) {
      patientService.getById(id).then(data => {
        // Map response fields to form — dateOfBirth comes as array or string
        reset({
          ...data,
          dateOfBirth: Array.isArray(data.dateOfBirth)
            ? `${data.dateOfBirth[0]}-${String(data.dateOfBirth[1]).padStart(2,'0')}-${String(data.dateOfBirth[2]).padStart(2,'0')}`
            : data.dateOfBirth,
        })
        setLoading(false)
      }).catch(() => {
        dispatch(showSnackbar({ message: 'Failed to load patient', severity: 'error' }))
        navigate('/patients')
      })
    }
  }, [id])

  const onSubmit = async (data) => {
    setSaving(true)
    try {
      if (isEdit) {
        // PUT /api/patients/{patientId}
        await patientService.update(id, data)
        dispatch(showSnackbar({ message: 'Patient updated successfully', severity: 'success' }))
      } else {
        // POST /api/patients?authUserId={authUserId}
        // authUserId links the patient profile to the Auth user record
        await patientService.create(data, user?.id)
        dispatch(showSnackbar({ message: 'Patient registered successfully', severity: 'success' }))
      }
      navigate('/patients')
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to save patient'
      dispatch(showSnackbar({ message: msg, severity: 'error' }))
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <Loader />

  return (
    <Box>
      <PageHeader title={isEdit ? 'Edit Patient' : 'Add Patient'} subtitle={isEdit ? 'Update patient information' : 'Register a new patient'} />

      <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate>
        {/* Personal Information */}
        <Card sx={{ mb: 3 }}>
          <CardContent sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight={600} sx={{ mb: 2.5 }}>Personal Information</Typography>
            <Grid container spacing={2.5}>
              <Grid item xs={12} sm={6}>
                <TextField label="First Name" fullWidth {...register('firstName')} error={!!errors.firstName} helperText={errors.firstName?.message} />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField label="Last Name" fullWidth {...register('lastName')} error={!!errors.lastName} helperText={errors.lastName?.message} />
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField select label="Gender" fullWidth defaultValue="" {...register('gender')} error={!!errors.gender} helperText={errors.gender?.message}>
                  {GENDERS.map(g => <MenuItem key={g} value={g}>{g}</MenuItem>)}
                </TextField>
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField label="Date of Birth" type="date" fullWidth {...register('dateOfBirth')} error={!!errors.dateOfBirth} helperText={errors.dateOfBirth?.message} InputLabelProps={{ shrink: true }} />
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField select label="Blood Group" fullWidth defaultValue="" {...register('bloodGroup')} error={!!errors.bloodGroup} helperText={errors.bloodGroup?.message}>
                  {BLOOD_GROUPS.map(b => <MenuItem key={b} value={b}>{BLOOD_LABELS[b]}</MenuItem>)}
                </TextField>
              </Grid>
            </Grid>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card sx={{ mb: 3 }}>
          <CardContent sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight={600} sx={{ mb: 2.5 }}>Contact Information</Typography>
            <Grid container spacing={2.5}>
              <Grid item xs={12} sm={6}>
                <TextField label="Email Address" type="email" fullWidth {...register('email')} error={!!errors.email} helperText={errors.email?.message} />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField label="Phone Number" fullWidth {...register('phoneNumber')} error={!!errors.phoneNumber} helperText={errors.phoneNumber?.message} placeholder="10-digit mobile number" />
              </Grid>
              <Grid item xs={12}>
                <TextField label="Address" fullWidth multiline rows={2} {...register('address')} error={!!errors.address} helperText={errors.address?.message} />
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField label="City" fullWidth {...register('city')} error={!!errors.city} helperText={errors.city?.message} />
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField label="State" fullWidth {...register('state')} error={!!errors.state} helperText={errors.state?.message} />
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField label="Pincode" fullWidth {...register('pincode')} error={!!errors.pincode} helperText={errors.pincode?.message} placeholder="6-digit pincode" />
              </Grid>
            </Grid>
          </CardContent>
        </Card>

        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button type="submit" variant="contained" startIcon={<Save />} disabled={saving}>
            {saving ? 'Saving…' : 'Save Patient'}
          </Button>
          <Button variant="outlined" startIcon={<Cancel />} onClick={() => navigate('/patients')}>Cancel</Button>
        </Box>
      </Box>
    </Box>
  )
}

export default PatientForm
