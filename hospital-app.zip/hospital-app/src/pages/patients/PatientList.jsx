import React, { useState, useEffect } from 'react'
import {
  Card, CardContent, Box, Button, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, TablePagination, IconButton, Tooltip, Avatar
} from '@mui/material'
import { Add, Visibility, Edit, Delete, People } from '@mui/icons-material'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { PageHeader, SearchBar, EmptyState, ConfirmDialog } from '../../components/Loader'
import StatusChip from '../../components/StatusChip'
import { showSnackbar } from '../../redux/slices/uiSlice'
import patientService from '../../services/patientService'

function PatientList() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [patients, setPatients] = useState([])
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(10)
  const [loading, setLoading] = useState(true)
  const [deleteId, setDeleteId] = useState(null)

  const fetchPatients = async () => {
    setLoading(true)
    try {
      // GET /api/patients or GET /api/patients/search?keyword=
      const data = search
        ? await patientService.search(search)
        : await patientService.getAll()
      setPatients(Array.isArray(data) ? data : [])
    } catch {
      dispatch(showSnackbar({ message: 'Failed to load patients', severity: 'error' }))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchPatients() }, [search])

  const handleDelete = async () => {
    try {
      await patientService.delete(deleteId)
      dispatch(showSnackbar({ message: 'Patient deleted', severity: 'success' }))
      setDeleteId(null)
      fetchPatients()
    } catch {
      dispatch(showSnackbar({ message: 'Failed to delete patient', severity: 'error' }))
    }
  }

  // Client-side pagination
  const paged = patients.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)

  return (
    <Box>
      <PageHeader
        title="Patients"
        subtitle={`${patients.length} patients registered`}
        action={<Button variant="contained" startIcon={<Add />} onClick={() => navigate('/patients/new')}>Add Patient</Button>}
      />

      <Card>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ mb: 2 }}>
            <SearchBar value={search} onChange={e => { setSearch(e.target.value); setPage(0) }} placeholder="Search by name, email or phone…" />
          </Box>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  {['#', 'Patient', 'Gender', 'Phone', 'City', 'Status', 'Actions'].map(h => (
                    <TableCell key={h} sx={{ fontWeight: 600, color: 'text.secondary', fontSize: '0.8rem' }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {loading
                  ? Array.from({ length: 5 }).map((_, i) => (
                      <TableRow key={i}>{Array.from({ length: 7 }).map((_, j) => (
                        <TableCell key={j}><Box sx={{ height: 20, bgcolor: 'action.hover', borderRadius: 1 }} /></TableCell>
                      ))}</TableRow>
                    ))
                  : paged.length === 0
                  ? <TableRow><TableCell colSpan={7}><EmptyState icon={<People />} title="No patients found" /></TableCell></TableRow>
                  : paged.map((p, idx) => (
                    <TableRow key={p.patientId} hover>
                      <TableCell sx={{ color: 'text.secondary', fontSize: '0.8rem' }}>{page * rowsPerPage + idx + 1}</TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                          <Avatar sx={{ width: 32, height: 32, fontSize: '0.85rem', bgcolor: '#F97316' }}>
                            {p.firstName?.charAt(0)}
                          </Avatar>
                          <Box>
                            <Box sx={{ fontWeight: 500, fontSize: '0.875rem' }}>{p.firstName} {p.lastName}</Box>
                            <Box sx={{ fontSize: '0.75rem', color: 'text.secondary' }}>{p.email}</Box>
                          </Box>
                        </Box>
                      </TableCell>
                      <TableCell>{p.gender}</TableCell>
                      <TableCell>{p.phoneNumber}</TableCell>
                      <TableCell>{p.city}</TableCell>
                      <TableCell><StatusChip status={p.status} /></TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: 0.5 }}>
                          <Tooltip title="View"><IconButton size="small" color="info" onClick={() => navigate(`/patients/${p.patientId}`)}><Visibility fontSize="small" /></IconButton></Tooltip>
                          <Tooltip title="Edit"><IconButton size="small" color="primary" onClick={() => navigate(`/patients/${p.patientId}/edit`)}><Edit fontSize="small" /></IconButton></Tooltip>
                          <Tooltip title="Delete"><IconButton size="small" color="error" onClick={() => setDeleteId(p.patientId)}><Delete fontSize="small" /></IconButton></Tooltip>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            component="div" count={patients.length} page={page}
            onPageChange={(_, p) => setPage(p)} rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(+e.target.value); setPage(0) }}
            rowsPerPageOptions={[5, 10, 25]}
          />
        </CardContent>
      </Card>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete}
        title="Delete Patient" message="Are you sure you want to delete this patient? This action cannot be undone." />
    </Box>
  )
}

export default PatientList
