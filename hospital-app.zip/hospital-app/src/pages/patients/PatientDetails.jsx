import React, { useEffect, useState } from 'react'
import {
  Grid, Card, CardContent, Typography, Box, Button, Avatar, Divider,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow
} from '@mui/material'
import { Edit, CalendarMonth, Assessment, Payment, ArrowBack } from '@mui/icons-material'
import { useParams, useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { PageHeader, Loader } from '../../components/Loader'
import StatusChip from '../../components/StatusChip'
import { showSnackbar } from '../../redux/slices/uiSlice'
import patientService from '../../services/patientService'

function InfoRow({ label, value }) {
  return (
    <Box sx={{ display: 'flex', py: 1.2, borderBottom: '1px solid', borderColor: 'divider' }}>
      <Typography variant="body2" color="text.secondary" sx={{ width: 160, flexShrink: 0 }}>{label}</Typography>
      <Typography variant="body2" fontWeight={500}>{value || '—'}</Typography>
    </Box>
  )
}

const BLOOD_LABELS = { A_POSITIVE:'A+', A_NEGATIVE:'A-', B_POSITIVE:'B+', B_NEGATIVE:'B-', AB_POSITIVE:'AB+', AB_NEGATIVE:'AB-', O_POSITIVE:'O+', O_NEGATIVE:'O-' }

function PatientDetails() {
  const { id } = useParams()
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [patient, setPatient] = useState(null)
  const [appointments, setAppointments] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      patientService.getById(id),
      patientService.getAppointments(id).catch(() => []),
    ]).then(([p, appts]) => {
      setPatient(p)
      setAppointments(Array.isArray(appts) ? appts : [])
    }).catch(() => {
      dispatch(showSnackbar({ message: 'Patient not found', severity: 'error' }))
      navigate('/patients')
    }).finally(() => setLoading(false))
  }, [id])

  if (loading) return <Loader />
  if (!patient) return null

  const fullName = `${patient.firstName} ${patient.lastName}`
  const dob = Array.isArray(patient.dateOfBirth)
    ? patient.dateOfBirth.join('-')
    : patient.dateOfBirth

  return (
    <Box>
      <PageHeader
        title="Patient Details"
        action={
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Button variant="outlined" startIcon={<ArrowBack />} onClick={() => navigate('/patients')}>Back</Button>
            <Button variant="contained" startIcon={<Edit />} onClick={() => navigate(`/patients/${patient.patientId}/edit`)}>Edit</Button>
          </Box>
        }
      />

      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent sx={{ p: 3, textAlign: 'center' }}>
              <Avatar sx={{ width: 80, height: 80, mx: 'auto', mb: 2, fontSize: '2rem', bgcolor: '#F97316' }}>
                {patient.firstName?.charAt(0)}
              </Avatar>
              <Typography variant="h6" fontWeight={700}>{fullName}</Typography>
              <Typography variant="body2" color="text.secondary">{patient.email}</Typography>
              <Typography variant="caption" color="text.secondary">{patient.patientNumber}</Typography>
              <Box sx={{ mt: 1.5 }}><StatusChip status={patient.status} /></Box>
              <Divider sx={{ my: 2 }} />
              <InfoRow label="Phone" value={patient.phoneNumber} />
              <InfoRow label="Gender" value={patient.gender} />
              <InfoRow label="Date of Birth" value={dob} />
              <InfoRow label="Blood Group" value={BLOOD_LABELS[patient.bloodGroup] || patient.bloodGroup} />
            </CardContent>
          </Card>

          <Card sx={{ mt: 2 }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" fontWeight={600} sx={{ mb: 1.5 }}>Address</Typography>
              <InfoRow label="Address" value={patient.address} />
              <InfoRow label="City" value={patient.city} />
              <InfoRow label="State" value={patient.state} />
              <InfoRow label="Pincode" value={patient.pincode} />
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={8}>
          <Card sx={{ mb: 2 }}>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                <Typography variant="h6" fontWeight={600}>Appointment History</Typography>
                <Button size="small" startIcon={<CalendarMonth />} onClick={() => navigate('/appointments/book')}>Book New</Button>
              </Box>
              {appointments.length === 0 ? (
                <Typography variant="body2" color="text.secondary">No appointments found.</Typography>
              ) : (
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        {['Date', 'Time', 'Status', 'Payment'].map(h => (
                          <TableCell key={h} sx={{ fontWeight: 600, color: 'text.secondary', fontSize: '0.8rem' }}>{h}</TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {appointments.map(a => (
                        <TableRow key={a.appointmentId} hover onClick={() => navigate(`/appointments/${a.appointmentId}`)} sx={{ cursor: 'pointer' }}>
                          <TableCell>{a.appointmentDate}</TableCell>
                          <TableCell>{a.appointmentTime}</TableCell>
                          <TableCell><StatusChip status={a.status} /></TableCell>
                          <TableCell><StatusChip status={a.paymentStatus} /></TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  )
}

export default PatientDetails
