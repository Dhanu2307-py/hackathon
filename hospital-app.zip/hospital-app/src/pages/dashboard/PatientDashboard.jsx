import React, { useEffect, useState } from "react";
import StatusChip from "../../components/StatusChip";
import appointmentService from "../../services/appointmentService";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { StatCard } from "../../components/Loader";
import { setNotifications } from "../../redux/slices/notificationSlice";
import { showSnackbar } from "../../redux/slices/uiSlice";
import { notificationService, reportService } from "../../services/otherServices";

import {
  Grid, Card, CardContent, Typography, Box, Button,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow
} from '@mui/material'
import {
  CalendarMonth, Payment, Assessment, Notifications,
  CheckCircle, HourglassEmpty, ArrowForward, Add
} from '@mui/icons-material'

function PatientDashboard() {
  const { user } = useSelector(s => s.auth)
  const { items: notifications } = useSelector(s => s.notifications)
  const navigate = useNavigate()
  const dispatch = useDispatch()

  const [appointments, setAppointments] = useState([])
  const [reports, setReports]           = useState([])
  const [loading, setLoading]           = useState(true)
  const [stats, setStats]               = useState({
    total: null, upcoming: null, completed: null, reports: null,
  })

  useEffect(() => { load() }, [])

  const load = async () => {
    setLoading(true)
    try {
      const results = await Promise.allSettled([
        // GET /appointments/patient/{patientProfileId}
        user?.patientProfileId
          ? appointmentService.getByPatient(user.patientProfileId)
          : Promise.resolve([]),
        // GET /reports/patient/{patientProfileId}
        user?.patientProfileId
          ? reportService.getByPatient(user.patientProfileId)
          : Promise.resolve([]),
        notificationService.getAll(user?.id),
      ])

      const appts = results[0].status === 'fulfilled'
        ? (Array.isArray(results[0].value) ? results[0].value : [])
        : []

      const rpts = results[1].status === 'fulfilled'
        ? (Array.isArray(results[1].value) ? results[1].value : [])
        : []

      if (results[2].status === 'fulfilled') {
        dispatch(setNotifications(Array.isArray(results[2].value) ? results[2].value : []))
      }

      setAppointments(appts)
      setReports(rpts)
      setStats({
        total:     appts.length,
        upcoming:  appts.filter(a => !['COMPLETED','CANCELLED','REFUNDED'].includes(a.status)).length,
        completed: appts.filter(a => a.status === 'COMPLETED').length,
        reports:   rpts.length,
      })
    } catch {
      dispatch(showSnackbar({ message: 'Failed to load dashboard data', severity: 'warning' }))
    } finally {
      setLoading(false)
    }
  }

  // Recent appointments — latest 5
  const recentAppointments = [...appointments]
    .sort((a, b) => String(b.appointmentDate).localeCompare(String(a.appointmentDate)))
    .slice(0, 5)

  // Recent reports — latest 3
  const recentReports = reports.slice(0, 3)

  const latestNotifs = notifications.slice(0, 3)

  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h5" fontWeight={700}>
          Hello, {user?.name?.split(' ')[0]} 👋
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Here's a summary of your health appointments and reports
        </Typography>
      </Box>

      {/* KPI Cards */}
      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        {[
          { title: 'Total Appointments', value: stats.total,     icon: <CalendarMonth />, color: '#F97316' },
          { title: 'Upcoming',           value: stats.upcoming,  icon: <HourglassEmpty />,color: '#2563EB' },
          { title: 'Completed',          value: stats.completed, icon: <CheckCircle />,   color: '#16A34A' },
          { title: 'My Reports',         value: stats.reports,   icon: <Assessment />,    color: '#8B5CF6' },
        ].map(card => (
          <Grid item xs={12} sm={6} lg={3} key={card.title}>
            <StatCard title={card.title} value={loading ? null : (card.value ?? 0)} icon={card.icon} color={card.color} loading={loading} />
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        {/* Recent Appointments */}
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6" fontWeight={600}>My Appointments</Typography>
                <Button size="small" endIcon={<ArrowForward />} onClick={() => navigate('/appointments')}>View all</Button>
              </Box>
              {loading ? (
                <Typography variant="body2" color="text.secondary">Loading…</Typography>
              ) : recentAppointments.length === 0 ? (
                <Box sx={{ py: 4, textAlign: 'center' }}>
                  <CalendarMonth sx={{ fontSize: 40, color: 'text.disabled', mb: 1 }} />
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>No appointments yet</Typography>
                  <Button variant="contained" size="small" startIcon={<Add />} onClick={() => navigate('/appointments/book')}>
                    Book Now
                  </Button>
                </Box>
              ) : (
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        {['ID', 'Date', 'Time', 'Status', 'Payment'].map(h => (
                          <TableCell key={h} sx={{ fontWeight: 600, color: 'text.secondary', fontSize: '0.8rem' }}>{h}</TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {recentAppointments.map(a => (
                        <TableRow key={a.appointmentId} hover sx={{ cursor: 'pointer' }}
                          onClick={() => navigate(`/appointments/${a.appointmentId}`)}>
                          <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>#{a.appointmentId}</TableCell>
                          <TableCell>{a.appointmentDate}</TableCell>
                          <TableCell>{a.appointmentTime}</TableCell>
                          <TableCell><StatusChip status={a.status} /></TableCell>
                          <TableCell><StatusChip status={a.paymentStatus} /></TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Notifications */}
        <Grid item xs={12} md={4}>
          <Card sx={{ height: '100%' }}>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6" fontWeight={600}>Notifications</Typography>
                <Button size="small" endIcon={<ArrowForward />} onClick={() => navigate('/notifications')}>View all</Button>
              </Box>
              {latestNotifs.length === 0 ? (
                <Typography variant="body2" color="text.secondary">{loading ? 'Loading…' : 'No notifications'}</Typography>
              ) : (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                  {latestNotifs.map(n => {
                    const isRead = n.isRead ?? n.read ?? false
                    return (
                      <Box key={n.id} sx={{ display: 'flex', gap: 1.5, p: 1.5, borderRadius: 2, bgcolor: isRead ? 'transparent' : '#FFF7ED', border: '1px solid', borderColor: isRead ? 'divider' : '#FED7AA' }}>
                        <Notifications sx={{ fontSize: 18, color: isRead ? 'text.secondary' : '#F97316', flexShrink: 0, mt: 0.2 }} />
                        <Box>
                          {n.title && <Typography variant="caption" fontWeight={600} display="block">{n.title}</Typography>}
                          <Typography variant="caption" color="text.secondary">{n.message}</Typography>
                        </Box>
                      </Box>
                    )
                  })}
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Recent Reports */}
      <Card sx={{ mb: 3 }}>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6" fontWeight={600}>My Reports</Typography>
            <Button size="small" endIcon={<ArrowForward />} onClick={() => navigate('/reports')}>View all</Button>
          </Box>
          {loading ? (
            <Typography variant="body2" color="text.secondary">Loading…</Typography>
          ) : recentReports.length === 0 ? (
            <Typography variant="body2" color="text.secondary">No reports available yet.</Typography>
          ) : (
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {['Report ID', 'Appointment', 'Diagnosis', 'Next Visit', 'Status'].map(h => (
                      <TableCell key={h} sx={{ fontWeight: 600, color: 'text.secondary', fontSize: '0.8rem' }}>{h}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {recentReports.map(r => (
                    <TableRow key={r.reportId} hover sx={{ cursor: 'pointer' }}
                      onClick={() => navigate(`/reports/${r.reportId}`)}>
                      <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>#{r.reportId}</TableCell>
                      <TableCell>#{r.appointmentId}</TableCell>
                      <TableCell sx={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.diagnosis}</TableCell>
                      <TableCell>{r.nextVisitDate}</TableCell>
                      <TableCell><StatusChip status={r.status} /></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
        <Button variant="contained" startIcon={<Add />} onClick={() => navigate('/appointments/book')}>
          Book Appointment
        </Button>
        <Button variant="outlined" startIcon={<Payment />} onClick={() => navigate('/payments')}>
          Make Payment
        </Button>
        <Button variant="outlined" startIcon={<Assessment />} onClick={() => navigate('/reports')}>
          My Reports
        </Button>
      </Box>
    </Box>
  )
}

export default PatientDashboard