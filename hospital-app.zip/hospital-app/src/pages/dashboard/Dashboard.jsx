import AdminDashboard from "./AdminDashboard";
import DoctorDashboard from "./DoctorDashboard";
import PatientDashboard from "./PatientDashboard";
import React from "react";
import { useSelector } from "react-redux";

function Dashboard() {
  const { role } = useSelector(s => s.auth)

  if (role === 'DOCTOR')  return <DoctorDashboard />
  if (role === 'PATIENT') return <PatientDashboard />
  return <AdminDashboard />
}

export default Dashboard