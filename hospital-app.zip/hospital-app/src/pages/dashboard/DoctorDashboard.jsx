import React, { useEffect, useState } from "react";
import StatusChip from "../../components/StatusChip";
import appointmentService from "../../services/appointmentService";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { StatCard } from "../../components/Loader";
import { setNotifications } from "../../redux/slices/notificationSlice";
import { showSnackbar } from "../../redux/slices/uiSlice";
import { notificationService } from "../../services/otherServices";

import {
  Grid, Card, CardContent, Typography, Box, Button,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Avatar
} from '@mui/material'
import {
  CalendarMonth, Assessment, Notifications,
  CheckCircle, HourglassEmpty, ArrowForward, EventAvailable
} from '@mui/icons-material'

function DoctorDashboard() {
  const { user } = useSelector(s => s.auth)
  const { items: notifications } = useSelector(s => s.notifications)
  const navigate = useNavigate()
  const dispatch = useDispatch()

  const [appointments, setAppointments] = useState([])
  const [loading, setLoading]           = useState(true)
  const [stats, setStats]               = useState({
    total: null, pending: null, confirmed: null, completed: null,
  })

  useEffect(() => { load() }, [])

  const load = async () => {
    setLoading(true)
    try {
      const results = await Promise.allSettled([
        // GET /appointments/doctor/{doctorId}
        user?.doctorId
          ? appointmentService.getByDoctor(user.doctorId)
          : Promise.resolve([]),
        notificationService.getAll(user?.id),
      ])

      const appts = results[0].status === 'fulfilled'
        ? (Array.isArray(results[0].value) ? results[0].value : [])
        : []

      if (results[1].status === 'fulfilled') {
        dispatch(setNotifications(Array.isArray(results[1].value) ? results[1].value : []))
      }

      setAppointments(appts)
      setStats({
        total:     appts.length,
        pending:   appts.filter(a => a.status === 'PENDING').length,
        confirmed: appts.filter(a => a.status === 'CONFIRMED' || a.status === 'WAITING_FOR_DOCTOR').length,
        completed: appts.filter(a => a.status === 'COMPLETED').length,
      })
    } catch {
      dispatch(showSnackbar({ message: 'Failed to load dashboard data', severity: 'warning' }))
    } finally {
      setLoading(false)
    }
  }

  // Today's appointments
  const today = new Date().toISOString().split('T')[0]
  const todayAppointments = appointments.filter(a => {
    const apptDate = Array.isArray(a.appointmentDate)
      ? `${a.appointmentDate[0]}-${String(a.appointmentDate[1]).padStart(2,'0')}-${String(a.appointmentDate[2]).padStart(2,'0')}`
      : a.appointmentDate
    return apptDate === today
  })

  // Upcoming (future, not completed/cancelled)
  const upcoming = appointments
    .filter(a => !['COMPLETED','CANCELLED','REFUNDED'].includes(a.status))
    .sort((a, b) => String(a.appointmentDate).localeCompare(String(b.appointmentDate)))
    .slice(0, 5)

  const latestNotifs = notifications.slice(0, 3)

  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h5" fontWeight={700}>
          Good morning, Dr. {user?.name?.split(' ').slice(-1)[0]} 👋
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Here's your schedule and patient overview for today
        </Typography>
      </Box>

      {/* KPI Cards */}
      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        {[
          { title: 'Total Appointments', value: stats.total,     icon: <CalendarMonth />, color: '#F97316' },
          { title: "Today's Patients",   value: todayAppointments.length, icon: <EventAvailable />, color: '#2563EB' },
          { title: 'Pending',            value: stats.pending,   icon: <HourglassEmpty />,color: '#D97706' },
          { title: 'Completed',          value: stats.completed, icon: <CheckCircle />,   color: '#16A34A' },
        ].map(card => (
          <Grid item xs={12} sm={6} lg={3} key={card.title}>
            <StatCard title={card.title} value={loading ? null : (card.value ?? 0)} icon={card.icon} color={card.color} loading={loading} />
          </Grid>
        ))}
      </Grid>

      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        {/* Today's Appointments */}
        <Grid item xs={12} md={7}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6" fontWeight={600}>Today's Appointments</Typography>
                <Button size="small" endIcon={<ArrowForward />} onClick={() => navigate('/appointments')}>View all</Button>
              </Box>
              {loading ? (
                <Typography variant="body2" color="text.secondary">Loading…</Typography>
              ) : todayAppointments.length === 0 ? (
                <Box sx={{ py: 4, textAlign: 'center' }}>
                  <CalendarMonth sx={{ fontSize: 40, color: 'text.disabled', mb: 1 }} />
                  <Typography variant="body2" color="text.secondary">No appointments scheduled for today</Typography>
                </Box>
              ) : (
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        {['Patient ID', 'Time', 'Status', 'Fee'].map(h => (
                          <TableCell key={h} sx={{ fontWeight: 600, color: 'text.secondary', fontSize: '0.8rem' }}>{h}</TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {todayAppointments.map(a => (
                        <TableRow key={a.appointmentId} hover sx={{ cursor: 'pointer' }}
                          onClick={() => navigate(`/appointments/${a.appointmentId}`)}>
                          <TableCell>#{a.patientProfileId}</TableCell>
                          <TableCell>{a.appointmentTime}</TableCell>
                          <TableCell><StatusChip status={a.status} /></TableCell>
                          <TableCell>₹{a.consultationFee}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </CardContent>
          </Card>
        </Grid>

        {/* Upcoming Appointments */}
        <Grid item xs={12} md={5}>
          <Card sx={{ height: '100%' }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>Upcoming</Typography>
              {loading ? (
                <Typography variant="body2" color="text.secondary">Loading…</Typography>
              ) : upcoming.length === 0 ? (
                <Typography variant="body2" color="text.secondary">No upcoming appointments</Typography>
              ) : (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                  {upcoming.map(a => (
                    <Box key={a.appointmentId}
                      onClick={() => navigate(`/appointments/${a.appointmentId}`)}
                      sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 1.5, borderRadius: 2, bgcolor: 'action.hover', cursor: 'pointer', '&:hover': { bgcolor: 'action.selected' } }}>
                      <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: '#FFF7ED', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <CalendarMonth sx={{ fontSize: 20, color: '#F97316' }} />
                      </Box>
                      <Box sx={{ flex: 1 }}>
                        <Typography variant="body2" fontWeight={500}>Patient #{a.patientProfileId}</Typography>
                        <Typography variant="caption" color="text.secondary">
                          {a.appointmentDate} at {a.appointmentTime}
                        </Typography>
                      </Box>
                      <StatusChip status={a.status} />
                    </Box>
                  ))}
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Notifications */}
      <Card sx={{ mb: 3 }}>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6" fontWeight={600}>Notifications</Typography>
            <Button size="small" endIcon={<ArrowForward />} onClick={() => navigate('/notifications')}>View all</Button>
          </Box>
          {latestNotifs.length === 0 ? (
            <Typography variant="body2" color="text.secondary">{loading ? 'Loading…' : 'No notifications'}</Typography>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
              {latestNotifs.map(n => {
                const isRead = n.isRead ?? n.read ?? false
                return (
                  <Box key={n.id} sx={{ display: 'flex', gap: 1.5, p: 1.5, borderRadius: 2, bgcolor: isRead ? 'transparent' : '#FFF7ED', border: '1px solid', borderColor: isRead ? 'divider' : '#FED7AA' }}>
                    <Notifications sx={{ fontSize: 18, color: isRead ? 'text.secondary' : '#F97316', flexShrink: 0, mt: 0.2 }} />
                    <Box>
                      {n.title && <Typography variant="caption" fontWeight={600} display="block">{n.title}</Typography>}
                      <Typography variant="caption" color="text.secondary">{n.message}</Typography>
                    </Box>
                  </Box>
                )
              })}
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
        <Button variant="contained" startIcon={<CalendarMonth />} onClick={() => navigate('/appointments')}>My Appointments</Button>
        <Button variant="outlined" startIcon={<Assessment />} onClick={() => navigate('/reports')}>My Reports</Button>
        <Button variant="outlined" startIcon={<EventAvailable />} onClick={() => navigate(`/doctors/${user?.doctorId}/availability`)}>
          Manage Availability
        </Button>
      </Box>
    </Box>
  )
}

export default DoctorDashboard