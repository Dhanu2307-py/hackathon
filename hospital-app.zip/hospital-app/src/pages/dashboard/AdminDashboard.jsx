import React, { useEffect, useState } from "react";
import StatusChip from "../../components/StatusChip";
import appointmentService from "../../services/appointmentService";
import doctorService from "../../services/doctorService";
import patientService from "../../services/patientService";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { StatCard } from "../../components/Loader";
import { setNotifications } from "../../redux/slices/notificationSlice";
import { showSnackbar } from "../../redux/slices/uiSlice";
import { notificationService } from "../../services/otherServices";

import {
  Grid, Card, CardContent, Typography, Box, Button,
  Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow
} from '@mui/material'
import {
  People, LocalHospital, CalendarMonth, Assessment,
  HourglassEmpty, Notifications, ArrowForward
} from '@mui/icons-material'
import {
  LineChart, Line, PieChart, Pie, Cell, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts'

const PIE_COLORS = ['#F97316', '#2563EB', '#16A34A', '#D97706', '#6B7280']

function AdminDashboard() {
  const { user } = useSelector(s => s.auth)
  const { items: notifications } = useSelector(s => s.notifications)
  const navigate = useNavigate()
  const dispatch = useDispatch()

  const [stats, setStats]                   = useState({ totalPatients: null, totalDoctors: null, pendingDoctors: null })
  const [recentAppointments, setRecent]     = useState([])
  const [departmentData, setDeptData]       = useState([])
  const [loading, setLoading]               = useState(true)

  useEffect(() => { load() }, [])

  const load = async () => {
    setLoading(true)
    try {
      const results = await Promise.allSettled([
        patientService.getAll(),
        doctorService.getAll(),
        doctorService.getPendingDoctors(),
        notificationService.getAll(user?.id),
      ])

      const patients       = results[0].status === 'fulfilled' ? (Array.isArray(results[0].value) ? results[0].value : []) : []
      const doctors        = results[1].status === 'fulfilled' ? (Array.isArray(results[1].value) ? results[1].value : []) : []
      const pendingDoctors = results[2].status === 'fulfilled' ? (Array.isArray(results[2].value) ? results[2].value : []) : []

      if (results[3].status === 'fulfilled') {
        dispatch(setNotifications(Array.isArray(results[3].value) ? results[3].value : []))
      }

      setStats({
        totalPatients:  patients.length,
        totalDoctors:   doctors.filter(d => d.approvalStatus === 'APPROVED').length,
        pendingDoctors: pendingDoctors.length,
      })

      // Department distribution
      const deptCount = {}
      doctors.filter(d => d.approvalStatus === 'APPROVED').forEach(d => {
        const dept = d.departmentName || 'Other'
        deptCount[dept] = (deptCount[dept] || 0) + 1
      })
      setDeptData(
        Object.entries(deptCount)
          .map(([name, value]) => ({ name, value }))
          .sort((a, b) => b.value - a.value)
          .slice(0, 5)
      )

    } catch {
      dispatch(showSnackbar({ message: 'Some dashboard data failed to load', severity: 'warning' }))
    } finally {
      setLoading(false)
    }
  }

  const latestNotifs = notifications.slice(0, 4)

  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h5" fontWeight={700}>
          Welcome, {user?.name?.split(' ')[0]} 👋
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Admin Overview — Hospital Management System
        </Typography>
      </Box>

      {/* KPI Cards */}
      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        {[
          { title: 'Total Patients',     value: stats.totalPatients,  icon: <People />,        color: '#2563EB', path: '/patients' },
          { title: 'Active Doctors',     value: stats.totalDoctors,   icon: <LocalHospital />, color: '#16A34A', path: '/doctors' },
          { title: 'Pending Approvals',  value: stats.pendingDoctors, icon: <HourglassEmpty />,color: '#D97706', path: '/doctors' },
          { title: 'Reports',            value: null,                 icon: <Assessment />,    color: '#8B5CF6', path: '/reports' },
        ].map(card => (
          <Grid item xs={12} sm={6} lg={3} key={card.title}>
            <Box onClick={() => navigate(card.path)} sx={{ cursor: 'pointer' }}>
              <StatCard title={card.title} value={loading ? null : (card.value ?? '—')} icon={card.icon} color={card.color} loading={loading} />
            </Box>
          </Grid>
        ))}
      </Grid>

      {/* Charts */}
      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>Doctors by Department</Typography>
              {departmentData.length === 0 ? (
                <Box sx={{ height: 220, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Typography variant="body2" color="text.secondary">{loading ? 'Loading…' : 'No data available'}</Typography>
                </Box>
              ) : (
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={departmentData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
                    <Tooltip />
                    <Bar dataKey="value" fill="#F97316" radius={[6, 6, 0, 0]} name="Doctors" />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card sx={{ height: '100%' }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" fontWeight={600} sx={{ mb: 2 }}>Distribution</Typography>
              {departmentData.length === 0 ? (
                <Box sx={{ height: 180, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Typography variant="body2" color="text.secondary">{loading ? 'Loading…' : 'No data'}</Typography>
                </Box>
              ) : (
                <>
                  <ResponsiveContainer width="100%" height={180}>
                    <PieChart>
                      <Pie data={departmentData} cx="50%" cy="50%" outerRadius={70} dataKey="value"
                        label={({ percent }) => `${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={11}>
                        {departmentData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                    {departmentData.map((d, i) => (
                      <Box key={d.name} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: PIE_COLORS[i % PIE_COLORS.length] }} />
                        <Typography variant="caption" color="text.secondary">{d.name}</Typography>
                      </Box>
                    ))}
                  </Box>
                </>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Notifications */}
      <Card sx={{ mb: 3 }}>
        <CardContent sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6" fontWeight={600}>Latest Notifications</Typography>
            <Button size="small" endIcon={<ArrowForward />} onClick={() => navigate('/notifications')}>View all</Button>
          </Box>
          {latestNotifs.length === 0 ? (
            <Typography variant="body2" color="text.secondary">{loading ? 'Loading…' : 'No notifications'}</Typography>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {latestNotifs.map(n => {
                const isRead = n.isRead ?? n.read ?? false
                return (
                  <Box key={n.id} sx={{ display: 'flex', gap: 1.5, alignItems: 'flex-start', cursor: 'pointer' }} onClick={() => navigate('/notifications')}>
                    <Box sx={{ width: 32, height: 32, borderRadius: 2, flexShrink: 0, bgcolor: isRead ? 'action.hover' : '#FFF7ED', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Notifications sx={{ fontSize: 16, color: isRead ? 'text.secondary' : '#F97316' }} />
                    </Box>
                    <Box>
                      {n.title && <Typography variant="caption" fontWeight={600} display="block">{n.title}</Typography>}
                      <Typography variant="caption" sx={{ color: 'text.primary', lineHeight: 1.4 }}>{n.message}</Typography>
                      <Typography variant="caption" display="block" color="text.secondary">
                        {n.createdAt ? new Date(n.createdAt).toLocaleString() : ''}
                      </Typography>
                    </Box>
                  </Box>
                )
              })}
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
        <Button variant="contained" startIcon={<People />} onClick={() => navigate('/patients')}>Manage Patients</Button>
        <Button variant="outlined" startIcon={<LocalHospital />} onClick={() => navigate('/doctors')}>Manage Doctors</Button>
        <Button variant="outlined" startIcon={<CalendarMonth />} onClick={() => navigate('/appointments')}>View Appointments</Button>
        <Button variant="outlined" startIcon={<Assessment />} onClick={() => navigate('/reports')}>View Reports</Button>
      </Box>
    </Box>
  )
}

export default AdminDashboard