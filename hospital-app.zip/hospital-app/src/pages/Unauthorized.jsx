import React from "react";
import { Home, LockOutlined } from "@mui/icons-material";
import { Box, Button, Typography } from "@mui/material";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

function Unauthorized() {
  const navigate = useNavigate()
  const { role } = useSelector(s => s.auth)

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        bgcolor: 'background.default',
        p: 4,
        textAlign: 'center',
      }}
    >
      <Box
        sx={{
          width: 80, height: 80, borderRadius: 4,
          bgcolor: '#FEF2F2', border: '2px solid #FECACA',
          display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 3,
        }}
      >
        <LockOutlined sx={{ fontSize: 40, color: '#DC2626' }} />
      </Box>

      <Typography variant="h4" fontWeight={800} color="error" gutterBottom>
        Access Denied
      </Typography>

      <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 400, mb: 4 }}>
        You do not have permission to access this page.
        Your current role is <strong>{role}</strong>.
      </Typography>

      <Button
        variant="contained"
        startIcon={<Home />}
        onClick={() => navigate('/dashboard')}
      >
        Back to Dashboard
      </Button>
    </Box>
  )
}

export default Unauthorized