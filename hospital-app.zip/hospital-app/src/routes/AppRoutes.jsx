import Loader from "../components/Loader";
import MainLayout from "../layouts/MainLayout";
import ProtectedRoute from "../components/ProtectedRoute";
import React, { Suspense, lazy } from "react";
import { Navigate, Route, Routes } from "react-router-dom";

// ======================
// Public Pages
// ======================

const Login = lazy(() => import("../pages/auth/Login"));
const RegisterPatient = lazy(() => import("../pages/auth/RegisterPatient"));
const RegisterDoctor = lazy(() => import("../pages/auth/RegisterDoctor"));
const ForgotPassword = lazy(() => import("../pages/auth/ForgotPassword"));
const ResetPassword = lazy(() => import("../pages/auth/ResetPassword"));

// ======================
// Dashboard
// Dashboard.jsx internally renders
// AdminDashboard / DoctorDashboard / PatientDashboard
// ======================

const Dashboard = lazy(() => import("../pages/dashboard/Dashboard"));

// ======================
// Patient Module
// ======================

const PatientList = lazy(() => import("../pages/patients/PatientList"));
const PatientForm = lazy(() => import("../pages/patients/PatientForm"));
const PatientDetails = lazy(() => import("../pages/patients/PatientDetails"));

// ======================
// Doctor Module
// ======================

const DoctorList = lazy(() => import("../pages/doctors/DoctorList"));
const DoctorAvailability = lazy(() => import("../pages/doctors/DoctorAvailability"));

// ======================
// Appointment Module
// ======================

const AppointmentList = lazy(() => import("../pages/appointments/AppointmentList"));
const BookAppointment = lazy(() => import("../pages/appointments/BookAppointment"));
const AppointmentDetails = lazy(() => import("../pages/appointments/AppointmentDetails"));

// ======================
// Payment Module
// ======================

const PaymentPage = lazy(() => import("../pages/payments/PaymentPage"));
const PaymentHistory = lazy(() => import("../pages/payments/PaymentHistory"));

// ======================
// Report Module
// ======================

const ReportsList = lazy(() => import("../pages/reports/ReportsList"));
const ReportDetails = lazy(() => import("../pages/reports/ReportDetails"));

// ======================
// Notification Module
// ======================

const NotificationList = lazy(() => import("../pages/notifications/NotificationList"));

// ======================
// User Module
// ======================

const Profile = lazy(() => import("../pages/user/Profile"));
const Settings = lazy(() => import("../pages/user/Settings"));

// ======================
// Misc Pages
// ======================

const Unauthorized = lazy(() => import("../pages/Unauthorized"));
const NotFound = lazy(() => import("../pages/NotFound"));

function AppRoutes() {
  return (
    <Suspense fallback={<Loader fullScreen />}>
      <Routes>

        {/* ================= PUBLIC ROUTES ================= */}

        <Route path="/login" element={<Login />} />
        <Route path="/register/patient" element={<RegisterPatient />} />
        <Route path="/register/doctor" element={<RegisterDoctor />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/unauthorized" element={<Unauthorized />} />

        {/* ================= PROTECTED ROUTES ================= */}

        <Route element={<ProtectedRoute roles={["ADMIN", "DOCTOR", "PATIENT"]} />}>
          <Route element={<MainLayout />}>

            {/* Dashboard */}
            <Route path="/dashboard" element={<Dashboard />} />

            {/* Profile */}
            <Route path="/profile" element={<Profile />} />
            <Route path="/settings" element={<Settings />} />

            {/* Notifications */}
            <Route
              path="/notifications"
              element={<NotificationList />}
            />

            {/* Appointments */}
            <Route
              path="/appointments"
              element={<AppointmentList />}
            />
            <Route
              path="/appointments/book"
              element={<BookAppointment />}
            />
            <Route
              path="/appointments/:id"
              element={<AppointmentDetails />}
            />

            {/* Reports */}
            <Route
              path="/reports"
              element={<ReportsList />}
            />
            <Route
              path="/reports/:id"
              element={<ReportDetails />}
            />

            {/* Payments */}
            <Route element={<ProtectedRoute roles={["ADMIN", "PATIENT"]} />}>
              <Route
                path="/payments"
                element={<PaymentPage />}
              />
              <Route
                path="/payments/history"
                element={<PaymentHistory />}
              />
            </Route>

            {/* Doctors */}
            <Route element={<ProtectedRoute roles={["ADMIN", "DOCTOR"]} />}>
              <Route
                path="/doctors"
                element={<DoctorList />}
              />
              <Route
                path="/doctors/:id/availability"
                element={<DoctorAvailability />}
              />
            </Route>

            {/* Patients */}
            <Route element={<ProtectedRoute roles={["ADMIN"]} />}>
              <Route
                path="/patients"
                element={<PatientList />}
              />
              <Route
                path="/patients/new"
                element={<PatientForm />}
              />
              <Route
                path="/patients/:id"
                element={<PatientDetails />}
              />
              <Route
                path="/patients/:id/edit"
                element={<PatientForm />}
              />
            </Route>

          </Route>
        </Route>

        {/* ================= DEFAULT ROUTE ================= */}

        <Route
          path="/"
          element={<Navigate to="/login" replace />}
        />

        {/* ================= 404 ================= */}

        <Route
          path="*"
          element={<NotFound />}
        />

      </Routes>
    </Suspense>
  );
}

export default AppRoutes;