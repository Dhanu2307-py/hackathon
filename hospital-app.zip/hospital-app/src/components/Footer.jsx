import React from 'react'
import { Box, Typography, useTheme } from '@mui/material'

function Footer() {
  const theme = useTheme()
  const isDark = theme.palette.mode === 'dark'

  return (
    <Box
      component="footer"
      sx={{
        py: 2,
        px: 3,
        borderTop: `1px solid ${isDark ? 'rgba(148,163,184,0.12)' : '#E2E8F0'}`,
        bgcolor: 'background.paper',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: 1,
      }}
    >
      <Typography variant="caption" color="text.secondary">
        Hospital Appointment &amp; Patient Management System
      </Typography>
      <Box sx={{ display: 'flex', gap: 2 }}>
        <Typography variant="caption" color="text.secondary">Version 1.0</Typography>
        <Typography variant="caption" color="text.secondary">•</Typography>
        <Typography variant="caption" color="text.secondary">Hackathon Project</Typography>
      </Box>
    </Box>
  )
}

export default Footer
