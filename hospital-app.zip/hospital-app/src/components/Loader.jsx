import React from 'react'
import {
  Box, CircularProgress, Card, CardContent, Typography, Skeleton,
  TextField, InputAdornment, Dialog, DialogTitle, DialogContent,
  DialogContentText, DialogActions, Button
} from '@mui/material'
import { Search, TrendingUp, TrendingDown } from '@mui/icons-material'

// ─── Loader ───────────────────────────────────────────────────────────────────
export function Loader({ fullScreen }) {
  if (fullScreen) {
    return (
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', bgcolor: 'background.default' }}>
        <CircularProgress color="primary" size={48} thickness={4} />
      </Box>
    )
  }
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', py: 8 }}>
      <CircularProgress color="primary" size={40} thickness={4} />
    </Box>
  )
}

export default Loader

// ─── StatCard ─────────────────────────────────────────────────────────────────
export function StatCard({ title, value, icon, color = '#F97316', trend, trendLabel, loading }) {
  const bg = `${color}15`
  return (
    <Card sx={{ height: '100%' }}>
      <CardContent sx={{ p: 3 }}>
        {loading ? (
          <>
            <Skeleton width="60%" height={20} />
            <Skeleton width="40%" height={40} sx={{ mt: 1 }} />
          </>
        ) : (
          <>
            <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
              <Box>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 1, fontWeight: 500 }}>
                  {title}
                </Typography>
                <Typography variant="h4" sx={{ fontWeight: 700, color: 'text.primary' }}>
                  {value ?? '—'}
                </Typography>
                {trendLabel && (
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 1 }}>
                    {trend >= 0 ? <TrendingUp sx={{ fontSize: 16, color: 'success.main' }} /> : <TrendingDown sx={{ fontSize: 16, color: 'error.main' }} />}
                    <Typography variant="caption" color={trend >= 0 ? 'success.main' : 'error.main'} fontWeight={500}>
                      {trendLabel}
                    </Typography>
                  </Box>
                )}
              </Box>
              <Box sx={{ width: 48, height: 48, borderRadius: 2.5, bgcolor: bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                {React.cloneElement(icon, { sx: { color, fontSize: 24 } })}
              </Box>
            </Box>
          </>
        )}
      </CardContent>
    </Card>
  )
}

// ─── PageHeader ───────────────────────────────────────────────────────────────
export function PageHeader({ title, subtitle, action }) {
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3, flexWrap: 'wrap', gap: 2 }}>
      <Box>
        <Typography variant="h5" fontWeight={700}>{title}</Typography>
        {subtitle && <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>{subtitle}</Typography>}
      </Box>
      {action && <Box>{action}</Box>}
    </Box>
  )
}

// ─── EmptyState ───────────────────────────────────────────────────────────────
export function EmptyState({ icon, title = 'No data found', subtitle }) {
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', py: 8, color: 'text.secondary' }}>
      {icon && React.cloneElement(icon, { sx: { fontSize: 56, mb: 2, opacity: 0.3 } })}
      <Typography variant="h6" fontWeight={600} gutterBottom>{title}</Typography>
      {subtitle && <Typography variant="body2" color="text.secondary">{subtitle}</Typography>}
    </Box>
  )
}

// ─── SearchBar ────────────────────────────────────────────────────────────────
export function SearchBar({ value, onChange, placeholder = 'Search…', sx }) {
  return (
    <TextField
      size="small"
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <Search sx={{ fontSize: 18, color: 'text.secondary' }} />
          </InputAdornment>
        ),
      }}
      sx={{ minWidth: 240, ...sx }}
    />
  )
}

// ─── ConfirmDialog ────────────────────────────────────────────────────────────
export function ConfirmDialog({ open, onClose, onConfirm, title = 'Confirm Action', message = 'Are you sure?', confirmLabel = 'Confirm', confirmColor = 'error' }) {
  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle sx={{ fontWeight: 600 }}>{title}</DialogTitle>
      <DialogContent>
        <DialogContentText>{message}</DialogContentText>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} variant="outlined">Cancel</Button>
        <Button onClick={onConfirm} variant="contained" color={confirmColor}>
          {confirmLabel}
        </Button>
      </DialogActions>
    </Dialog>
  )
}
