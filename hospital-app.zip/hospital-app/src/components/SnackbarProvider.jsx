import React from 'react'
import { Snackbar, Alert } from '@mui/material'
import { useSelector, useDispatch } from 'react-redux'
import { hideSnackbar } from '../redux/slices/uiSlice'

export function SnackbarProvider({ children }) {
  const dispatch = useDispatch()
  const { open, message, severity } = useSelector((s) => s.ui.snackbar)

  return (
    <>
      {children}
      <Snackbar
        open={open}
        autoHideDuration={4000}
        onClose={() => dispatch(hideSnackbar())}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={() => dispatch(hideSnackbar())}
          severity={severity}
          variant="filled"
          sx={{ borderRadius: 2, minWidth: 280 }}
        >
          {message}
        </Alert>
      </Snackbar>
    </>
  )
}
