import React, { useState } from 'react'
import {
  AppBar, Toolbar, IconButton, Typography, InputBase, Box,
  Badge, Avatar, Menu, MenuItem, Divider, Tooltip, useTheme
} from '@mui/material'
import {
  Menu as MenuIcon, Search, Notifications, Person, Settings,
  Logout, KeyboardArrowDown, LightMode, DarkMode
} from '@mui/icons-material'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate, useLocation } from 'react-router-dom'
import { logout } from '../redux/slices/authSlice'
import { toggleThemeMode } from '../redux/slices/uiSlice'

const pageTitles = {
  '/dashboard': 'Dashboard',
  '/patients': 'Patients',
  '/doctors': 'Doctors',
  '/appointments': 'Appointments',
  '/payments': 'Payments',
  '/reports': 'Reports',
  '/notifications': 'Notifications',
  '/profile': 'Profile',
  '/settings': 'Settings',
}

function Navbar({ onMenuClick }) {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const location = useLocation()
  const muiTheme = useTheme()
  const isDark = muiTheme.palette.mode === 'dark'
  const { user } = useSelector((s) => s.auth)
  const { unreadCount } = useSelector((s) => s.notifications)
  const [anchorEl, setAnchorEl] = useState(null)

  const pageTitle = Object.entries(pageTitles).find(([key]) => location.pathname.startsWith(key))?.[1] || 'MediCare'

  const handleLogout = () => {
    dispatch(logout())
    navigate('/login')
  }

  return (
    <AppBar
      position="sticky"
      elevation={0}
      sx={{
        bgcolor: 'background.paper',
        borderBottom: `1px solid ${isDark ? 'rgba(148,163,184,0.12)' : '#E2E8F0'}`,
        zIndex: (t) => t.zIndex.drawer - 1,
      }}
    >
      <Toolbar sx={{ gap: 2 }}>
        {/* Mobile menu button */}
        <IconButton
          edge="start"
          onClick={onMenuClick}
          sx={{ display: { md: 'none' }, color: 'text.primary' }}
        >
          <MenuIcon />
        </IconButton>

        {/* Page title */}
        <Typography variant="h6" sx={{ fontWeight: 600, color: 'text.primary', flexShrink: 0 }}>
          {pageTitle}
        </Typography>

        {/* Search bar */}
        <Box
          sx={{
            flexGrow: 1,
            mx: 2,
            bgcolor: isDark ? 'rgba(148,163,184,0.08)' : '#F1F5F9',
            borderRadius: 3,
            display: 'flex',
            alignItems: 'center',
            px: 2,
            py: 0.5,
            maxWidth: 400,
            border: isDark ? '1px solid rgba(148,163,184,0.12)' : '1px solid transparent',
          }}
        >
          <Search sx={{ color: 'text.secondary', mr: 1, fontSize: 20 }} />
          <InputBase
            placeholder="Search patients, doctors…"
            sx={{ flex: 1, fontSize: '0.875rem', color: 'text.primary' }}
          />
        </Box>

        <Box sx={{ flexGrow: 1 }} />

        {/* Dark mode toggle */}
        <Tooltip title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}>
          <IconButton
            onClick={() => dispatch(toggleThemeMode())}
            sx={{ color: 'text.secondary' }}
          >
            {isDark ? <LightMode /> : <DarkMode />}
          </IconButton>
        </Tooltip>

        {/* Notifications */}
        <Tooltip title="Notifications">
          <IconButton onClick={() => navigate('/notifications')} sx={{ color: 'text.secondary' }}>
            <Badge badgeContent={unreadCount} color="error" max={9}>
              <Notifications />
            </Badge>
          </IconButton>
        </Tooltip>

        {/* User avatar + dropdown */}
        <Box
          onClick={(e) => setAnchorEl(e.currentTarget)}
          sx={{
            display: 'flex', alignItems: 'center', gap: 1, cursor: 'pointer',
            borderRadius: 3, px: 1.5, py: 0.5,
            '&:hover': { bgcolor: isDark ? 'rgba(148,163,184,0.08)' : '#F1F5F9' },
            transition: 'background 0.15s',
          }}
        >
          <Avatar sx={{ width: 32, height: 32, bgcolor: 'primary.main', fontSize: '0.85rem' }}>
            {user?.name?.charAt(0) || 'U'}
          </Avatar>
          <Typography variant="body2" sx={{ fontWeight: 500, display: { xs: 'none', sm: 'block' }, color: 'text.primary' }}>
            {user?.name || 'User'}
          </Typography>
          <KeyboardArrowDown sx={{ fontSize: 18, color: 'text.secondary' }} />
        </Box>

        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={() => setAnchorEl(null)}
          PaperProps={{ sx: { mt: 1, minWidth: 180, borderRadius: 2 } }}
        >
          <MenuItem onClick={() => { navigate('/profile'); setAnchorEl(null) }}>
            <Person sx={{ mr: 1.5, fontSize: 18 }} /> Profile
          </MenuItem>
          <MenuItem onClick={() => { navigate('/settings'); setAnchorEl(null) }}>
            <Settings sx={{ mr: 1.5, fontSize: 18 }} /> Settings
          </MenuItem>
          <Divider />
          <MenuItem onClick={handleLogout} sx={{ color: 'error.main' }}>
            <Logout sx={{ mr: 1.5, fontSize: 18 }} /> Logout
          </MenuItem>
        </Menu>
      </Toolbar>
    </AppBar>
  )
}

export default Navbar
