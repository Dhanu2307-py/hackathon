import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { logout } from "../redux/slices/authSlice";

import {
  Drawer, Box, List, ListItem, ListItemButton, ListItemIcon,
  ListItemText, Typography, Divider, Avatar
} from '@mui/material'
import {
  Dashboard, People, LocalHospital, CalendarMonth, Payment,
  Assessment, Notifications, Person, Settings, Logout, MedicalServices
} from '@mui/icons-material'

/*
  roles: array of roles that can see this menu item.
  If roles is undefined, all authenticated roles can see it.
*/
const navItems = [
  { label: 'Dashboard',     icon: <Dashboard />,     path: '/dashboard',    roles: ['ADMIN','DOCTOR','PATIENT'] },
  { label: 'Patients',      icon: <People />,         path: '/patients',     roles: ['ADMIN'] },
  { label: 'Doctors',       icon: <LocalHospital />,  path: '/doctors',      roles: ['ADMIN','DOCTOR'] },
  { label: 'Appointments',  icon: <CalendarMonth />,  path: '/appointments', roles: ['ADMIN','DOCTOR','PATIENT'] },
  { label: 'Payments',      icon: <Payment />,        path: '/payments',     roles: ['ADMIN','PATIENT'] },
  { label: 'Reports',       icon: <Assessment />,     path: '/reports',      roles: ['ADMIN','DOCTOR','PATIENT'] },
  { label: 'Notifications', icon: <Notifications />,  path: '/notifications',roles: ['ADMIN','DOCTOR','PATIENT'] },
  { label: 'Profile',       icon: <Person />,         path: '/profile',      roles: ['ADMIN','DOCTOR','PATIENT'] },
  { label: 'Settings',      icon: <Settings />,       path: '/settings',     roles: ['ADMIN','DOCTOR','PATIENT'] },
]

function SidebarContent({ onClose }) {
  const navigate = useNavigate()
  const location = useLocation()
  const dispatch = useDispatch()
  const { user, role } = useSelector(s => s.auth)

  // Filter nav items to only show what the current role can access
  const visibleItems = navItems.filter(item =>
    !item.roles || item.roles.includes(role)
  )

  const handleNav = (path) => {
    navigate(path)
    onClose?.()
  }

  const handleLogout = () => {
    dispatch(logout())
    navigate('/login')
  }

  return (
    <Box sx={{
      width: '100%', height: '100%', bgcolor: '#1E293B',
      display: 'flex', flexDirection: 'column', color: '#CBD5E1',
    }}>
      {/* Logo */}
      <Box sx={{ p: 3, display: 'flex', alignItems: 'center', gap: 1.5 }}>
        <Box sx={{
          width: 40, height: 40, borderRadius: 2, bgcolor: 'primary.main',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <MedicalServices sx={{ color: 'white', fontSize: 22 }} />
        </Box>
        <Box>
          <Typography variant="h6" sx={{ color: 'white', fontWeight: 700, lineHeight: 1.2, fontSize: '1rem' }}>
            MediCare
          </Typography>
          <Typography variant="caption" sx={{ color: '#64748B', fontSize: '0.7rem' }}>
            Hospital Management
          </Typography>
        </Box>
      </Box>

      <Divider sx={{ borderColor: '#334155' }} />

      {/* User info */}
      <Box sx={{ px: 2.5, py: 2, display: 'flex', alignItems: 'center', gap: 1.5 }}>
        <Avatar sx={{ width: 36, height: 36, bgcolor: 'primary.main', fontSize: '0.9rem' }}>
          {user?.name?.charAt(0) || 'U'}
        </Avatar>
        <Box>
          <Typography variant="body2" sx={{ color: 'white', fontWeight: 500, lineHeight: 1.2 }}>
            {user?.name || 'User'}
          </Typography>
          <Typography variant="caption" sx={{ color: '#64748B', fontSize: '0.7rem' }}>
            {role || 'USER'}
          </Typography>
        </Box>
      </Box>

      <Divider sx={{ borderColor: '#334155', mb: 1 }} />

      {/* Role-filtered nav items */}
      <List sx={{ flexGrow: 1, px: 1.5 }}>
        {visibleItems.map(item => {
          const active = location.pathname.startsWith(item.path)
          return (
            <ListItem key={item.path} disablePadding sx={{ mb: 0.5 }}>
              <ListItemButton
                onClick={() => handleNav(item.path)}
                sx={{
                  borderRadius: 2, py: 1, px: 1.5,
                  bgcolor: active ? 'rgba(249,115,22,0.15)' : 'transparent',
                  '&:hover': { bgcolor: active ? 'rgba(249,115,22,0.2)' : 'rgba(255,255,255,0.06)' },
                  transition: 'background 0.15s',
                }}
              >
                <ListItemIcon sx={{ minWidth: 36, color: active ? '#F97316' : '#94A3B8' }}>
                  {item.icon}
                </ListItemIcon>
                <ListItemText
                  primary={item.label}
                  primaryTypographyProps={{
                    fontSize: '0.875rem',
                    fontWeight: active ? 600 : 400,
                    color: active ? '#F97316' : '#CBD5E1',
                  }}
                />
                {active && (
                  <Box sx={{ width: 3, height: 20, bgcolor: '#F97316', borderRadius: 2, ml: 1 }} />
                )}
              </ListItemButton>
            </ListItem>
          )
        })}
      </List>

      <Divider sx={{ borderColor: '#334155' }} />

      {/* Logout */}
      <List sx={{ px: 1.5, py: 1 }}>
        <ListItem disablePadding>
          <ListItemButton
            onClick={handleLogout}
            sx={{ borderRadius: 2, py: 1, px: 1.5, '&:hover': { bgcolor: 'rgba(220,38,38,0.1)' } }}
          >
            <ListItemIcon sx={{ minWidth: 36, color: '#EF4444' }}>
              <Logout />
            </ListItemIcon>
            <ListItemText
              primary="Logout"
              primaryTypographyProps={{ fontSize: '0.875rem', color: '#EF4444' }}
            />
          </ListItemButton>
        </ListItem>
      </List>
    </Box>
  )
}

function Sidebar({ width, mobileOpen, onClose, isMobile }) {
  return (
    <>
      <Drawer
        variant="temporary" open={mobileOpen} onClose={onClose}
        ModalProps={{ keepMounted: true }}
        sx={{
          display: { xs: 'block', md: 'none' },
          '& .MuiDrawer-paper': { width, boxSizing: 'border-box', border: 'none' },
        }}
      >
        <SidebarContent onClose={onClose} />
      </Drawer>

      <Drawer
        variant="permanent"
        sx={{
          display: { xs: 'none', md: 'block' },
          '& .MuiDrawer-paper': { width, boxSizing: 'border-box', border: 'none', position: 'fixed', top: 0, left: 0, height: '100vh', zIndex: 1200 },
          width, flexShrink: 0,
        }}
        open
      >
        <SidebarContent />
      </Drawer>
    </>
  )
}

export default Sidebar