import React from 'react'
import { Chip } from '@mui/material'

/**
 * Maps ALL backend enum values to MUI chip colors.
 *
 * Covers enums from:
 * - UserStatus:        ACTIVE | INACTIVE | PENDING_APPROVAL | SUSPENDED
 * - PatientStatus:     ACTIVE | INACTIVE | BLOCKED
 * - DoctorStatus:      ACTIVE | INACTIVE | ON_LEAVE
 * - ApprovalStatus:    PENDING | APPROVED | REJECTED
 * - DepartmentStatus:  ACTIVE | HOLD
 * - LeaveStatus:       PENDING | APPROVED | REJECTED
 * - AppointmentStatus: PENDING_PAYMENT | PENDING | WAITING_FOR_DOCTOR | CONFIRMED |
 *                      RESCHEDULE_REQUESTED | COMPLETED | CANCELLED | REFUNDED
 * - PaymentStatus:     PENDING | PAID | REFUNDED | FAILED (appointment service)
 *                      SUCCESS | FAILED | REFUNDED  (payment service)
 * - ReportStatus:      DRAFT | COMPLETED | UPDATED
 * - NotificationType:  (shown as info chips elsewhere)
 */
const statusConfig = {
  // ─── Active / good ─────────────────────────────────────────────────────────
  ACTIVE:                { color: 'success', label: 'Active' },
  APPROVED:              { color: 'success', label: 'Approved' },
  CONFIRMED:             { color: 'success', label: 'Confirmed' },
  COMPLETED:             { color: 'success', label: 'Completed' },
  PAID:                  { color: 'success', label: 'Paid' },
  SUCCESS:               { color: 'success', label: 'Success' },

  // ─── Warning / in-progress ──────────────────────────────────────────────────
  PENDING:               { color: 'warning', label: 'Pending' },
  PENDING_APPROVAL:      { color: 'warning', label: 'Pending Approval' },
  PENDING_PAYMENT:       { color: 'warning', label: 'Pending Payment' },
  WAITING_FOR_DOCTOR:    { color: 'warning', label: 'Waiting for Doctor' },
  RESCHEDULE_REQUESTED:  { color: 'warning', label: 'Reschedule Requested' },
  HOLD:                  { color: 'warning', label: 'On Hold' },
  ON_LEAVE:              { color: 'warning', label: 'On Leave' },
  DRAFT:                 { color: 'warning', label: 'Draft' },
  UPDATED:               { color: 'info',    label: 'Updated' },

  // ─── Error / negative ────────────────────────────────────────────────────────
  INACTIVE:              { color: 'error', label: 'Inactive' },
  BLOCKED:               { color: 'error', label: 'Blocked' },
  SUSPENDED:             { color: 'error', label: 'Suspended' },
  REJECTED:              { color: 'error', label: 'Rejected' },
  CANCELLED:             { color: 'error', label: 'Cancelled' },
  FAILED:                { color: 'error', label: 'Failed' },

  // ─── Info / neutral ──────────────────────────────────────────────────────────
  REFUNDED:              { color: 'info', label: 'Refunded' },
}

function StatusChip({ status }) {
  if (!status) return null
  const config = statusConfig[status] || { color: 'default', label: status.replace(/_/g, ' ') }
  return (
    <Chip
      label={config.label}
      color={config.color}
      size="small"
      sx={{ fontWeight: 600, fontSize: '0.72rem' }}
    />
  )
}

export default StatusChip
