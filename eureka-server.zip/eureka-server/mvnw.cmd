@REM Maven Wrapper Script (Windows)
@REM Licensed to the Apache Software Foundation (ASF)

@IF "%__MVNW_ARG0_NAME__%"=="MVNW_USERNAME" (SET MVNW_USERNAME=%__MVNW_ARG0__%
) ELSE IF "%__MVNW_ARG0_NAME__%"=="MVNW_PASSWORD" (SET MVNW_PASSWORD=%__MVNW_ARG0__%
)

@SET MAVEN_PROJECTBASEDIR=%MAVEN_BASEDIR%
@IF "%MAVEN_PROJECTBASEDIR%"=="" @SET MAVEN_PROJECTBASEDIR=%~dp0

@SET WRAPPER_JAR=%MAVEN_PROJECTBASEDIR%\.mvn\wrapper\maven-wrapper.jar

@SET WRAPPER_LAUNCHER=org.apache.maven.wrapper.MavenWrapperMain
@SET DOWNLOAD_URL=

@FOR /F "tokens=1,2 delims==" %%a IN (%MAVEN_PROJECTBASEDIR%\.mvn\wrapper\maven-wrapper.properties) DO (
    @IF "%%a"=="distributionUrl" @SET DOWNLOAD_URL=%%b
)

@"%JAVA_HOME%\bin\java.exe" -classpath "%WRAPPER_JAR%" "-Dmaven.multiModuleProjectDirectory=%MAVEN_PROJECTBASEDIR%" %WRAPPER_LAUNCHER% %MAVEN_CONFIG% %*
