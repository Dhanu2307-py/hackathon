package com.hospital.eurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * Eureka Service Registry
 *
 * Acts as the central service registry for the
 * Hospital Appointment & Patient Management System.
 *
 * All microservices (Auth, Patient, Doctor, Appointment,
 * Report, Notification, Payment) register themselves here.
 *
 * The API Gateway and Feign Clients use this registry
 * to discover and communicate with other services.
 *
 * Dashboard: http://localhost:8761
 */
@SpringBootApplication
@EnableEurekaServer
public class EurekaServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(EurekaServerApplication.class, args);
    }

}
