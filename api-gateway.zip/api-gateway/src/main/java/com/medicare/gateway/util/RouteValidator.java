package com.medicare.gateway.util;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.function.Predicate;

/**
 * Determines whether an incoming request is public (no JWT required)
 * or protected (JWT required).
 *
 * Public endpoints match React frontend auth pages:
 *   - src/pages/auth/Login.jsx          → POST /auth/login
 *   - src/pages/auth/RegisterPatient.jsx → POST /auth/register/patient
 *   - src/pages/auth/RegisterDoctor.jsx  → POST /auth/register/doctor
 *   - src/pages/auth/ForgotPassword.jsx  → POST /auth/forgot-password
 *   - src/pages/auth/ResetPassword.jsx   → POST /auth/reset-password
 */
@Component
public class RouteValidator {

    // These paths bypass JWT validation
    public static final List<String> PUBLIC_PATHS = List.of(
            "/auth/login",
            "/auth/register/patient",
            "/auth/register/doctor",
            "/auth/forgot-password",
            "/auth/reset-password"
    );

    /**
     * Returns true if the request requires JWT authentication.
     */
    public Predicate<ServerHttpRequest> isSecured() {
        return request -> PUBLIC_PATHS.stream()
                .noneMatch(uri -> request.getURI().getPath().equals(uri));
    }

    /**
     * Returns true if the request is public (no JWT needed).
     */
    public boolean isPublicPath(String path) {
        return PUBLIC_PATHS.stream().anyMatch(path::equals);
    }
}
