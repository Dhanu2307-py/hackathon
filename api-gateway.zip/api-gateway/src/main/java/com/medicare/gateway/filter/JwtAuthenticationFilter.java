package com.medicare.gateway.filter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.medicare.gateway.exception.ErrorResponse;
import com.medicare.gateway.util.JwtUtil;
import com.medicare.gateway.util.RouteValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * JWT Authentication Gateway Filter.
 *
 * Applied to every route in application.yml via:
 *   filters:
 *     - name: JwtAuthenticationFilter
 *
 * Flow:
 *   1. Check if path is public → pass through
 *   2. Check Authorization header exists
 *   3. Extract and validate JWT token
 *   4. Forward userId, email, role as headers to downstream services
 *   5. Reject with 401 if token missing or invalid
 */
@Component
@Slf4j
public class JwtAuthenticationFilter extends AbstractGatewayFilterFactory<JwtAuthenticationFilter.Config> {

    private final JwtUtil jwtUtil;
    private final RouteValidator routeValidator;
    private final ObjectMapper objectMapper;

    public JwtAuthenticationFilter(JwtUtil jwtUtil, RouteValidator routeValidator) {
        super(Config.class);
        this.jwtUtil = jwtUtil;
        this.routeValidator = routeValidator;
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            ServerHttpRequest request = exchange.getRequest();
            String path = request.getURI().getPath();

            log.debug("Gateway filter processing: {} {}", request.getMethod(), path);

            // ── Step 1: Skip public paths (login, register) ───────────────────
            if (routeValidator.isPublicPath(path)) {
                log.debug("Public path, skipping auth: {}", path);
                return chain.filter(exchange);
            }

            // ── Step 2: Check Authorization header ────────────────────────────
            if (!request.getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
                log.warn("Missing Authorization header for: {}", path);
                return unauthorizedResponse(exchange, "Missing Authorization header. Please log in.");
            }

            String authHeader = request.getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                log.warn("Invalid Authorization header format for: {}", path);
                return unauthorizedResponse(exchange, "Invalid Authorization header format. Use: Bearer <token>");
            }

            String token = authHeader.substring(7);

            // ── Step 3: Validate JWT token ────────────────────────────────────
            if (!jwtUtil.isTokenValid(token)) {
                log.warn("Invalid or expired JWT token for: {}", path);
                return unauthorizedResponse(exchange, "Token is expired or invalid. Please log in again.");
            }

            // ── Step 4: Extract claims and forward as headers ─────────────────
            try {
                String email  = jwtUtil.extractEmail(token);
                String role   = jwtUtil.extractRole(token);
                Long   userId = jwtUtil.extractUserId(token);

                log.debug("Authenticated request — userId: {}, role: {}, path: {}", userId, role, path);

                // Mutate request to add user context headers.
                // Downstream microservices can read:
                //   @RequestHeader("X-User-Id") Long userId
                //   @RequestHeader("X-User-Role") String role
                //   @RequestHeader("X-User-Email") String email
                ServerHttpRequest mutatedRequest = request.mutate()
                        .header("X-User-Id",    userId != null ? userId.toString() : "")
                        .header("X-User-Role",  role   != null ? role              : "")
                        .header("X-User-Email", email  != null ? email             : "")
                        .build();

                return chain.filter(exchange.mutate().request(mutatedRequest).build());

            } catch (Exception e) {
                log.error("Error extracting JWT claims: {}", e.getMessage());
                return unauthorizedResponse(exchange, "Token processing failed. Please log in again.");
            }
        };
    }

    // ─── Helper: write 401 JSON response ─────────────────────────────────────

    private Mono<Void> unauthorizedResponse(ServerWebExchange exchange, String message) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(HttpStatus.UNAUTHORIZED);
        response.getHeaders().setContentType(MediaType.APPLICATION_JSON);

        ErrorResponse error = ErrorResponse.of(
                401, message, exchange.getRequest().getURI().getPath());

        try {
            byte[] bytes = objectMapper.writeValueAsBytes(error);
            DataBuffer buffer = response.bufferFactory().wrap(bytes);
            return response.writeWith(Mono.just(buffer));
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize error response: {}", e.getMessage());
            return response.setComplete();
        }
    }

    // ─── Config class required by AbstractGatewayFilterFactory ───────────────

    public static class Config {
        // No configuration properties needed for this filter.
        // Can be extended in the future for role-based access.
    }
}
