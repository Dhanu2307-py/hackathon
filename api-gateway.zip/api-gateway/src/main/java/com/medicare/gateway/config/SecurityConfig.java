package com.medicare.gateway.config;

import com.medicare.gateway.exception.GatewayAccessDeniedHandler;
import com.medicare.gateway.exception.GatewayAuthEntryPoint;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

/**
 * Reactive Spring Security configuration for the API Gateway.
 *
 * IMPORTANT: Spring Cloud Gateway is WebFlux-based (reactive).
 * We use @EnableWebFluxSecurity, NOT @EnableWebSecurity.
 *
 * JWT validation happens in JwtAuthenticationFilter (a GatewayFilter),
 * so we disable Spring Security's built-in authentication here
 * and delegate all auth logic to our custom filter.
 *
 * This avoids conflicts between Spring Security and the Gateway filter.
 */
@Configuration
@EnableWebFluxSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final GatewayAuthEntryPoint authEntryPoint;
    private final GatewayAccessDeniedHandler accessDeniedHandler;

    @Bean
    public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
        return http
                // Disable CSRF — stateless JWT API, no session
                .csrf(ServerHttpSecurity.CsrfSpec::disable)

                // Disable HTTP Basic and form login — we use JWT
                .httpBasic(ServerHttpSecurity.HttpBasicSpec::disable)
                .formLogin(ServerHttpSecurity.FormLoginSpec::disable)

                // Exception handling — return JSON, not HTML redirect
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint(authEntryPoint)
                        .accessDeniedHandler(accessDeniedHandler)
                )

                // Permit all requests here — actual JWT validation is done
                // in JwtAuthenticationFilter (GatewayFilter) before Spring Security
                .authorizeExchange(auth -> auth
                        .anyExchange().permitAll()
                )

                .build();
    }
}
