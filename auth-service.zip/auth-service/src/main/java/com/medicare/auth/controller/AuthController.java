package com.medicare.auth.controller;

import com.medicare.auth.dto.request.LoginRequest;
import com.medicare.auth.dto.request.RegisterDoctorRequest;
import com.medicare.auth.dto.request.RegisterPatientRequest;
import com.medicare.auth.dto.response.ApiResponse;
import com.medicare.auth.dto.response.AuthResponse;
import com.medicare.auth.dto.response.UserResponse;
import com.medicare.auth.dto.response.ValidateTokenResponse;
import com.medicare.auth.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthController {

    private final AuthService authService;

    // ─── POST /auth/register/patient ──────────────────────────────────────────
    // Public endpoint. Registers a patient user in auth DB with ACTIVE status.
    // React frontend: src/pages/auth/RegisterPatient.jsx
    // After registration, Patient Service creates the full profile using authUserId.

    @PostMapping("/register/patient")
    public ResponseEntity<ApiResponse<AuthResponse>> registerPatient(
            @Valid @RequestBody RegisterPatientRequest request) {

        log.info("Patient registration request for email: {}", request.getEmail());
        AuthResponse response = authService.registerPatient(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success("Patient registered successfully.", response));
    }

    // ─── POST /auth/register/doctor ───────────────────────────────────────────
    // Public endpoint. Registers a doctor user in auth DB with PENDING_APPROVAL status.
    // React frontend: src/pages/auth/RegisterDoctor.jsx
    // Doctor cannot login until Admin approves via Doctor Service.

    @PostMapping("/register/doctor")
    public ResponseEntity<ApiResponse<AuthResponse>> registerDoctor(
            @Valid @RequestBody RegisterDoctorRequest request) {

        log.info("Doctor registration request for email: {}", request.getEmail());
        AuthResponse response = authService.registerDoctor(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success(
                        "Doctor registration submitted. Awaiting admin approval.", response));
    }

    // ─── POST /auth/login ─────────────────────────────────────────────────────
    // Public endpoint. Returns JWT token + user + role.
    // React frontend: src/services/authService.js → login()
    // Redux: loginSuccess({ token, user, role })

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(
            @Valid @RequestBody LoginRequest request) {

        log.info("Login request for email: {}", request.getEmail());
        AuthResponse response = authService.login(request);

        return ResponseEntity.ok(ApiResponse.success("Login successful.", response));
    }

    // ─── GET /auth/profile ────────────────────────────────────────────────────
    // Protected endpoint. Returns logged-in user profile.
    // Requires valid JWT Bearer token in Authorization header.

    @GetMapping("/profile")
    public ResponseEntity<ApiResponse<UserResponse>> getProfile(
            @AuthenticationPrincipal UserDetails userDetails) {

        UserResponse profile = authService.getProfile(userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Profile fetched successfully.", profile));
    }

    // ─── GET /auth/validate ───────────────────────────────────────────────────
    // Called by API Gateway to validate JWT token before routing to microservices.
    // Returns userId, email, role so Gateway can forward them as headers.

    @GetMapping("/validate")
    public ResponseEntity<ApiResponse<ValidateTokenResponse>> validateToken(
            @RequestHeader("Authorization") String authorizationHeader) {

        String token = authorizationHeader.startsWith("Bearer ")
                ? authorizationHeader.substring(7)
                : authorizationHeader;

        ValidateTokenResponse result = authService.validateToken(token);

        if (result.isValid()) {
            return ResponseEntity.ok(ApiResponse.success("Token is valid.", result));
        } else {
            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error(result.getMessage()));
        }
    }
}
