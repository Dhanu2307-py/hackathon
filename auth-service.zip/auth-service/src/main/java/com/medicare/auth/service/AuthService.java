package com.medicare.auth.service;

import com.medicare.auth.dto.request.LoginRequest;
import com.medicare.auth.dto.request.RegisterDoctorRequest;
import com.medicare.auth.dto.request.RegisterPatientRequest;
import com.medicare.auth.dto.response.AuthResponse;
import com.medicare.auth.dto.response.UserResponse;
import com.medicare.auth.dto.response.ValidateTokenResponse;

public interface AuthService {

    AuthResponse registerPatient(RegisterPatientRequest request);

    AuthResponse registerDoctor(RegisterDoctorRequest request);

    AuthResponse login(LoginRequest request);

    UserResponse getProfile(String email);

    ValidateTokenResponse validateToken(String token);
}
