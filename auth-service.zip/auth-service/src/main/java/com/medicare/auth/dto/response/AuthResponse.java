package com.medicare.auth.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthResponse {

    // Fields match exactly what React Redux authSlice expects:
    // loginSuccess({ token, user, role })
    private String token;
    private String role;
    private UserResponse user;
}
