package com.medicare.auth.service;

import com.medicare.auth.dto.request.LoginRequest;
import com.medicare.auth.dto.request.RegisterDoctorRequest;
import com.medicare.auth.dto.request.RegisterPatientRequest;
import com.medicare.auth.dto.response.AuthResponse;
import com.medicare.auth.dto.response.UserResponse;
import com.medicare.auth.dto.response.ValidateTokenResponse;
import com.medicare.auth.entity.Role;
import com.medicare.auth.entity.User;
import com.medicare.auth.entity.UserStatus;
import com.medicare.auth.exception.AuthExceptions;
import com.medicare.auth.mapper.UserMapper;
import com.medicare.auth.repository.UserRepository;
import com.medicare.auth.security.JwtService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private final UserMapper userMapper;

    // ─── Register Patient ─────────────────────────────────────────────────────
    // Patient gets ACTIVE status immediately on registration.
    // The full patient profile (name, DOB, address etc.) is created separately
    // by Patient Service using the authUserId returned here.

    @Override
    @Transactional
    public AuthResponse registerPatient(RegisterPatientRequest request) {
        log.info("Registering patient with email: {}", request.getEmail());

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new AuthExceptions.EmailAlreadyExistsException(request.getEmail());
        }

        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phoneNumber(request.getPhoneNumber())
                .role(Role.PATIENT)
                .status(UserStatus.ACTIVE)   // Patients are active immediately
                .build();

        User saved = userRepository.save(user);
        log.info("Patient registered successfully with id: {}", saved.getId());

        String token = jwtService.generateTokenWithClaims(
                saved.getEmail(), saved.getId(), saved.getRole().name());

        return AuthResponse.builder()
                .token(token)
                .role(saved.getRole().name())
                .user(userMapper.toUserResponse(saved))
                .build();
    }

    // ─── Register Doctor ──────────────────────────────────────────────────────
    // Doctor gets PENDING_APPROVAL status on registration.
    // Admin must approve via Doctor Service (admin/doctors/{id}/approve).
    // The doctor profile (specialization, fee etc.) is managed by Doctor Service.

    @Override
    @Transactional
    public AuthResponse registerDoctor(RegisterDoctorRequest request) {
        log.info("Registering doctor with email: {}", request.getEmail());

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new AuthExceptions.EmailAlreadyExistsException(request.getEmail());
        }

        // Store doctor's display name — use doctorName field from request
        User user = User.builder()
                .name(request.getDoctorName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phoneNumber(request.getPhone())
                .role(Role.DOCTOR)
                .status(UserStatus.PENDING_APPROVAL)  // Doctors need admin approval
                .build();

        User saved = userRepository.save(user);
        log.info("Doctor registered with PENDING_APPROVAL, id: {}", saved.getId());

        // No token issued yet — doctor cannot login until approved
        // Frontend shows pending message after registration
        return AuthResponse.builder()
                .token(null)
                .role(saved.getRole().name())
                .user(userMapper.toUserResponse(saved))
                .build();
    }

    // ─── Login ────────────────────────────────────────────────────────────────

    @Override
    public AuthResponse login(LoginRequest request) {
        log.info("Login attempt for email: {}", request.getEmail());

        // Spring Security validates credentials via AuthenticationManager
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new AuthExceptions.UserNotFoundException(
                        "User not found: " + request.getEmail()));

        // Block login for PENDING_APPROVAL or SUSPENDED accounts
        if (user.getStatus() == UserStatus.PENDING_APPROVAL) {
            throw new AuthExceptions.AccountNotActiveException(user.getStatus().name());
        }
        if (user.getStatus() == UserStatus.SUSPENDED || user.getStatus() == UserStatus.INACTIVE) {
            throw new AuthExceptions.AccountNotActiveException(user.getStatus().name());
        }

        String token = jwtService.generateTokenWithClaims(
                user.getEmail(), user.getId(), user.getRole().name());

        log.info("Login successful for: {} with role: {}", user.getEmail(), user.getRole());

        return AuthResponse.builder()
                .token(token)
                .role(user.getRole().name())
                .user(userMapper.toUserResponse(user))
                .build();
    }

    // ─── Get Profile ──────────────────────────────────────────────────────────

    @Override
    public UserResponse getProfile(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new AuthExceptions.UserNotFoundException(
                        "User not found: " + email));
        return userMapper.toUserResponse(user);
    }

    // ─── Validate Token ───────────────────────────────────────────────────────
    // Called by API Gateway to validate incoming JWT tokens before routing.

    @Override
    public ValidateTokenResponse validateToken(String token) {
        try {
            if (!jwtService.isTokenValid(token)) {
                return ValidateTokenResponse.builder()
                        .valid(false)
                        .message("Token is expired or invalid")
                        .build();
            }

            String email = jwtService.extractUsername(token);
            String role  = jwtService.extractRole(token);
            Long userId  = jwtService.extractUserId(token);

            return ValidateTokenResponse.builder()
                    .valid(true)
                    .email(email)
                    .role(role)
                    .userId(userId)
                    .message("Token is valid")
                    .build();

        } catch (Exception e) {
            log.warn("Token validation failed: {}", e.getMessage());
            return ValidateTokenResponse.builder()
                    .valid(false)
                    .message("Token validation failed: " + e.getMessage())
                    .build();
        }
    }
}
