package com.medicare.auth.entity;

public enum UserStatus {
    ACTIVE,
    INACTIVE,
    PENDING_APPROVAL,
    SUSPENDED
}
