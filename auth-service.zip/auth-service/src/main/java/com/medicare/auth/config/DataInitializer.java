package com.medicare.auth.config;

import com.medicare.auth.entity.Role;
import com.medicare.auth.entity.User;
import com.medicare.auth.entity.UserStatus;
import com.medicare.auth.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        createDefaultAdmin();
    }

    private void createDefaultAdmin() {
        String adminEmail = "admin@medicare.com";

        if (userRepository.existsByEmail(adminEmail)) {
            log.info("Default admin already exists, skipping creation.");
            return;
        }

        User admin = User.builder()
                .name("Admin User")
                .email(adminEmail)
                .password(passwordEncoder.encode("admin123"))
                .role(Role.ADMIN)
                .status(UserStatus.ACTIVE)
                .phoneNumber("9999999999")
                .build();

        userRepository.save(admin);
        log.info("✅ Default admin created → email: {} | password: admin123", adminEmail);
        log.info("⚠️  Change the default admin password after first login!");
    }
}
