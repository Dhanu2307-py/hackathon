package com.medicare.auth.entity;

public enum Role {
    ADMIN,
    DOCTOR,
    PATIENT
}
