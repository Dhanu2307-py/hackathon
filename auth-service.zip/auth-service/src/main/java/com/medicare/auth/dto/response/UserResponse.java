package com.medicare.auth.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserResponse {

    private Long id;
    private String name;      // used by React: user?.name
    private String email;
    private String role;
    private String status;
    private String phoneNumber;
    private LocalDateTime createdAt;
}
